singularities = { M2, M2 - 1/4*s, M2 - 1/4*s - 1/4*t, M2 - 1/4*t, M2^2 - 1/4*s*t, M2^2 - M2*s + 1/4*s^2 + 1/4*s*t, M2^2 - M2*t + 1/4*s*t + 1/4*t^2, s, s + t, t };
