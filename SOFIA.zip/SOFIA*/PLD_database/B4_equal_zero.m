singularities = { m2, m2 - 1/16*s, m2 - 1/4*s, s };
