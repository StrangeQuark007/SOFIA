singularities = { m2, m2 + 4/9*s, m2 - 1/4*s, m2 - 1/9*t, m2 - t, m2^2*s - 10/9*m2*s*t - 4/9*m2*t^2 + 1/9*s*t^2, s, s + t, t };
