singularities = { m2, m2 - 1/4*s, m2 - 1/4*t, m2*s + m2*t - 1/4*s*t, s, s + t, t };
