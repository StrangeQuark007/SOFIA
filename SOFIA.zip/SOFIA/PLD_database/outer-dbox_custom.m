singularities = { m2, m2 - 1/4*s, m2 - 1/4*t, m2*s + m2*t - 1/4*s*t, m2^2*s - 2*m2*s*t - 4*m2*t^2 + s*t^2, s, s + t, t };
