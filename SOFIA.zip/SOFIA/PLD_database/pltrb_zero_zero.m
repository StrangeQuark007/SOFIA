singularities = { s };
