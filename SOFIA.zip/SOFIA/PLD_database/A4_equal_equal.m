singularities = { M2, M2 - 1/4*s, M2 - 1/4*s - 1/4*t, M2 - 1/4*t, M2 - 4*m2, M2^2 - 4*M2*m2 + m2*s, M2^2 - 4*M2*m2 + m2*s + m2*t - 1/4*s*t, M2^2 - 4*M2*m2 + m2*t, m2, m2 - 1/4*s, m2 - 1/4*t, s, t };
