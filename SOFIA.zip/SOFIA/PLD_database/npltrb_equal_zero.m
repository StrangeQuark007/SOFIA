singularities = { m2, m2 + 1/12*s, m2 + 4/9*s, m2 - 1/4*s, m2 - 1/9*s, m2 - s, s };
