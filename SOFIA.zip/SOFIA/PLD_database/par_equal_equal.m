singularities = { M2, M2 - 1/4*s, M2 - 9*m2, M2 - m2, M2^2 - 10*M2*m2 + 9*m2^2 + 4*m2*s, m2, m2 - 1/4*s, s };
