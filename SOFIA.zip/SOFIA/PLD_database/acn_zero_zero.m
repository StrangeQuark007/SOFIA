singularities = { s, s + t, t };
