singularities = { M2, M2 - 1/4*s, s };
