singularities = { M2, M2 - 1/4*s, M2 - 1/4*s - 1/4*t, M2 - 1/4*t, M2^2 - 1/4*s*t, s, t };
