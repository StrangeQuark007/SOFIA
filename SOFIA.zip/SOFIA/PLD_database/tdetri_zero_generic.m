singularities = { M[3], M[3]^2 - 2*M[3]*M[4] - 2*M[3]*s + M[4]^2 - 2*M[4]*s + s^2, M[4], s };
