(* ::Package:: *)

BeginPackage["JULIA`"]


Print["
Mathematica wrapper to use functions behind PLD.jl by C. Fevola, S. Mizera and S. Telen (2023).
"]


Print["Copyright \[Copyright] 2025 Miguel Correia, Mathieu Giroux, and Sebastian Mizera. All rights reserved."]


momentumPLD::usage="..."
EulerDiscriminant::usage="..."
(*-------------------------*)
prepareVariables::usage="..."
defineCoefRing::usage="..."
defineLaurentRing::usage="..."
toJuliaString::usage="..."
ComputeDiscriminants::usage="..."
sendSystemToJulia::usage="..."


Begin["`Private`"]


(* ::Section:: *)
(*Dependencies*)


Echo["-------> [Loading external dependencies ...] <-------"];
js=StartExternalSession["Julia"]
ExternalEvaluate[js,"using Pkg"]
Echo["-------> [Looking for: Oscar, HomotopyContinuation and GAP ...] <-------"];
ExternalEvaluate[js,"Pkg.add(\"Oscar\")"]
ExternalEvaluate[js,"Pkg.add(\"HomotopyContinuation\")"]
ExternalEvaluate[js,"Pkg.add(\"GAP\")"]
Echo["-------> [Activate PLD ...] <-------"];
ExternalEvaluate[js,"Pkg.activate(\"/Users/feynman_voyager_2/Desktop/Landau/PLD/Project.toml\")"]
Echo["-------> [Loading PLD ...] <-------"];
ExternalEvaluate[js,"using PLD"]
ExternalEvaluate[js,"using GAP"]
ExternalEvaluate[js,"using Oscar"]
ExternalEvaluate[js,"using HomotopyContinuation"]
Echo["-------> [Checking status...] <-------"];
ExternalEvaluate[js,"Pkg.status()"]


(* ::Section:: *)
(*Helper functions*)


homogeneizeKin[arg_]:=arg//.Subscript[s, a___]:>ToExpression["s"<>StringJoin[ToString/@{a}]]//.Subscript[M, i_]:>Sqrt[ToExpression["MM"<>ToString[i]]]//.Subscript[m, i_]:>Sqrt[ToExpression["mm"<>ToString[i]]]//.M:>Sqrt[MM]//.m:>Sqrt[mm]


myPolynomialDecomposition[P_,vars_List]:=Module[{cr,monomials,coeffs},
cr=CoefficientRules[P,vars];
monomials=Map[Apply[Times,MapThread[#1^#2&,{vars,#}]]&,First/@cr];
coeffs=Last/@cr;
{coeffs,monomials}]


factorList[list_]:=Select[DeleteDuplicates[Flatten[Map[FactorList[#][[All,1]]&,list]]],!NumericQ[#]&]


(* ::Section::Closed:: *)
(*Numerical solver*)


(*Preparing conversion: polynomials in the input can depend on either {Subscript[l, _]\[CenterDot]_} OR {x1,...} as active variables.*)
prepareVariables[listOfGram_]:=Module[{},
Clear[toX,gramList,active,kinematics];
Echo[toX=Thread[#1->(ToExpression["x"<>ToString[#]]&/@Range[Length[#1]])]&[DeleteDuplicates[Cases[listOfGram,Alternatives@@{Subscript[l, _]\[CenterDot]_,_\[CenterDot]Subscript[l, _]},Infinity]]],"toX ="];
Echo[gramList=Factor[listOfGram//.toX],"gramDetList ="];
Echo[active=If[!SameQ[toX,{}],(toX/.Rule[a_,b_]:>b),DeleteDuplicates[Cases[listOfGram,x_Symbol/;StringMatchQ[SymbolName[x],"x"~~DigitCharacter..],{0,Infinity}]]],"active (loop) variables ="];
Echo[kinematics=DeleteCases[Variables[gramList],Alternatives@@active],"kinematics = "];
(*Echo[*)alphas=(ToExpression["\[Alpha]"<>ToString[#]]&/@Range[0,Length[#1]-1])&[listOfGram](*,"alphas = "]*);
(*Echo[*)Gs=(ToExpression["G"<>ToString[#]]&/@Range[0,Length[#1]-1])&[listOfGram](*,"G's = "]*);
Echo[allActive=Join[active,alphas],"allActive = "];
]


(* define ring of coefficients: *)
Clear[defineCoefRing]
defineCoefRing[kin_]:=Module[{},
varNames=SymbolName/@kin;
varTupleString="("<>StringRiffle[varNames,", "]<>")";
varListString="[\""<>StringRiffle[varNames,"\", \""]<>"\"]";
codeString="R, "<>varTupleString<>" = PolynomialRing(QQ, "<>varListString<>"); println(R); \"Ring defined\"";
result=ExternalEvaluate[js,codeString]
]
(* define Laurent polynomial ring (ring of active variables): *)
Clear[defineLaurentRing]
defineLaurentRing[allActive_]:=Module[{},
varNames2=SymbolName/@allActive;
varTupleString2="("<>StringRiffle[varNames2,", "]<>")";
varListString2="[\""<>StringRiffle[varNames2,"\", \""]<>"\"]";
codeString2="S, "<>varTupleString2<>" = LaurentPolynomialRing(R, "<>varListString2<>"); println(S); \"Laurent ring defined\"";
result2=ExternalEvaluate[js,codeString2]
]


(* processing polynomials to julia form: *)
toJuliaString[expr_]:=StringReplace[ToString[InputForm[expr]],{"Power["->"(",","->")^"," "->"","Plus["->"(","Times["->"(","]"->")","Sqrt["->"sqrt(","^"->"^"}];
giList[polynomials_]:=ExternalEvaluate[js,StringReplace[#,"/"->"//"]]&/@MapIndexed[Module[{giIndex,giName,polyString},giIndex=First[#2]-1;
giName="G"<>ToString[giIndex];
polyString=toJuliaString[#1];
codeString3=giName<>" = "<>polyString<>"; string("<>giName<>")";
codeString3]&,Numerator[Factor[polynomials]]];


(* call momentum space PLD: *)
ComputeDiscriminants[js_, methodNumOrSym_ : sym, homogeneousTrueOrFalse_ : false, highPrecTrueOrFalse_ : false, codimStart_ : -1, faceStart_ : 1, singleFace_ : false]:=Block[{codeString,result},
  codeString = "
    discriminants = getSpecializedPAD(Delta, gens(R), gens(S); high_prec="<>ToString[highPrecTrueOrFalse]<>", method=:"<>ToString[methodNumOrSym]<>", homogeneous="<>ToString[homogeneousTrueOrFalse]<>", codim_start="<>ToString[codimStart]<>", face_start="<>ToString[faceStart]<>", single_face="<>ToString[singleFace]<>");
    string(discriminants);
    \"Discriminants computed!\"
  ";
 (* remove leading/trailing whitespaces: *)
  codeString = StringTrim[codeString];
  result = ExternalEvaluate[js, codeString];
   Return[result];
]


(* generate system in Julia: *)
sendSystemToJulia[polynomials_]:=Module[{out},
temp1=prepareVariables[polynomials];
temp2=defineCoefRing[kinematics];
temp3=defineLaurentRing[allActive];
temp4=giList[gramList];
DELTA=Echo[ExternalEvaluate[js,"Delta = "<>StringReplace[ToString[InputForm[(alphas/.Thread[ToExpression["\[Alpha]"<>ToString[Length[gramList]-1]]->1](*//.\[Alpha]0->1*)) . Gs]],"\\[Alpha]"->"\[Alpha]"]<>"; string(Delta)"],"\[CapitalDelta] = "];
]


(* define and compute the principle (Landau) A discriminant: *)
momentumPLD[polynomials_, methodNumOrSym_ : sym, homogeneousTrueOrFalse_ : false, highPrecTrueOrFalse_ : false, codimStart_ : -1, faceStart_ : 1, singleFace_ : false]:=Module[{out},
temp1=prepareVariables[polynomials];
temp2=defineCoefRing[kinematics];
temp3=defineLaurentRing[allActive];
temp4=giList[gramList];
Echo[ExternalEvaluate[js,"Delta = "<>StringReplace[ToString[InputForm[(alphas/.Thread[ToExpression["\[Alpha]"<>ToString[Length[gramList]-1]]->1](*//.\[Alpha]0->1*)) . Gs]],"\\[Alpha]"->"\[Alpha]"]<>"; string(Delta)"],"\[CapitalDelta] = "];
out=ComputeDiscriminants[js, methodNumOrSym, homogeneousTrueOrFalse, highPrecTrueOrFalse, codimStart, faceStart, singleFace];
Return[out];
]


(* ::Section::Closed:: *)
(*Euler characteristic drops*)


(* define Laurent polynomial ring (ring of active variables): *)
Clear[defineLaurentRingEuler]
defineLaurentRingEuler[allActive_]:=Module[{},
varNames2Euler=SymbolName/@DeleteCases[allActive,\[Alpha]0];
varTupleString2Euler="("<>StringRiffle[varNames2Euler,", "]<>")";
varListString2Euler="[\""<>StringRiffle[varNames2Euler,"\", \""]<>"\"]";
codeString2Euler="SHOM, "<>varTupleString2Euler<>" = LaurentPolynomialRing(R, "<>varListString2Euler<>"); println(SHOM); \"Homogeneized Laurent ring defined\"";
result2Euler=ExternalEvaluate[js,codeString2Euler]
]
(* compares Euler characteristic near candidate singularities with generic Euler characteristic: *)
EulerDiscriminant[polynomials_,candidates0_,repeatsSteps_]:=Module[{out},
candidates=Select[candidates0,Length[#]>2&];(*TODO: seems that we need to drop Length[#]>2 for the algoritm not to complain...*)
QuietEcho[temp1=prepareVariables[polynomials]];
Echo["Homogeneized the system sending \[Alpha]0 -> 1!"];
temp2=defineCoefRing[kinematics];
temp3=defineLaurentRingEuler[allActive];
temp4=giList[gramList];
ExternalEvaluate[js,"DeltaHOM = "<>StringReplace[ToString[InputForm[(alphas//.\[Alpha]0->1) . Gs]],"\\[Alpha]"->"\[Alpha]"]<>"; string(DeltaHOM)"];
ExternalEvaluate[js, "can = "<>StringReplace[ToString[InputForm[candidates]], {"{" -> "[", "}" -> "]"}]<>"; string(can)"];
(*Echo[*)ExternalEvaluate[js,"ed = EulerDiscriminantQ(DeltaHOM, gens(R), gens(SHOM), can, repeats="<>ToString[repeatsSteps]<>"); string(ed)"](*,"Candidate singularities with Euler characteristic drop = "]*);
]


(* ::Section:: *)
(*End*)


End[]
EndPackage[];


(*Print documentation:*)
If[$Notebooks, 
  Print["Available documented functions:"];
  Print @ Column[
    {
    "momentumPLD",
    "EulerDiscriminant"
}, 
    Spacings -> 0.5
  ];
];
