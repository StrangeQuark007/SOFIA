singularities = { m2, m2 + 1/9*s, m2 + s, m2 - 1/16*s, m2 - 1/3*s, m2 - 1/4*s, s };
