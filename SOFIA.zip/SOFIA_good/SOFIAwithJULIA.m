(* ::Package:: *)

(*BeginPackage["SOFIA`"]*)


(*Begin["`Private`"]*)


(* ::Section::Closed:: *)
(*Effortless (2025) by A. Matija\[SHacek]i\[CAcute] and J. Miczajka*)


Options[RunEffortless]:={"ConstantCoefficientList"->{4},"CheckNumberProducts"->4,"CheckNumberLetters"->4,"Range"->1000,"Verbose"->True,"DoubleSquareRoots"->False,"ExtraPolynomials"->{1}}
RunEffortless[SqrtList_,EvenAlpha_,SqrtRepl_,vars_,OptionsPattern[]]:=
	Module[{AllowedLetters,OddLetters,AllOddLetters={},StartTime=AbsoluteTime[],LocalTime,AllZeroLocations,sqrtList},
			AllZeroLocations=FindAllZeroLocations[EvenAlpha];
			If[OptionValue["DoubleSquareRoots"]==True,sqrtList=Join[SqrtList,Table[SqrtList[[i]]SqrtList[[j]],{i,1,Length[SqrtList]},{j,i+1,Length[SqrtList]}]//Flatten],sqrtList=SqrtList];
			Do[
				(*Print["For coefficient c = "<>ToString[Currentc]<>":"];*)
				Do[
					LocalTime=AbsoluteTime[];
					If[OptionValue["Verbose"]==True,Print["--------- Analyzing square root: "<>ToString[CurrentSqrt]]];
	
					OddLetters=Flatten[Table[
										AllowedLetters=DeleteCases[AllowedEvenLetters[CurrentPoly CurrentSqrt,EvenAlpha,SqrtRepl,vars,"CheckNumberLetters"->OptionValue["CheckNumberLetters"],"AllZeroLocations"->AllZeroLocations,"Range"->OptionValue["Range"]],Rule[_,Log[CurrentPoly]]|Rule[_,Log[-CurrentPoly]],All];
										If[OptionValue["Verbose"]==True,Print["Found "<>ToString[Length[Flatten[AllowedLetters]]]<>" allowed letters for odd letters involving "<>ToString[CurrentPoly CurrentSqrt]<>"."]];
										FindOddLetters[CurrentPoly CurrentSqrt,AllowedLetters,SqrtRepl,vars,"ConstantCoefficient"->Currentc,"CheckNumberProducts"->OptionValue["CheckNumberProducts"],"Range"->OptionValue["Range"]],
									{CurrentPoly,OptionValue["ExtraPolynomials"]}]];
					If[OptionValue["Verbose"]==True,Print["Constructed "<>ToString[Length[OddLetters]]<>" odd letters in "<>ToString[AbsoluteTime[]-LocalTime]<>" seconds."]];
					AppendTo[AllOddLetters,OddLetters];
					,{CurrentSqrt,sqrtList}
				];
				,{Currentc,OptionValue["ConstantCoefficientList"]}
			];
			
				Print["Constructed "<>ToString[Length[Flatten[AllOddLetters]]]<>" odd letters, total runtime: "<>ToString[AbsoluteTime[]-StartTime]<>" seconds."];
				AllOddLetters
			];



CheckInputEvenAlphaQ[EvenAlpha_]:=
Module[{},
If[Head[EvenAlpha]===List,If[Head[EvenAlpha[[1]]]===Rule,{True},{False,"ERROR: Even Alphabet is not a list of rules."}]
,{False,"ERROR: Even Alphabet is not a list."}]	
]


Options[RunEffortlessIndependent]:={"ConstantCoefficientList"->{4},"CheckNumberProducts"->4,"CheckNumberLetters"->4,"Range"->1000,"NumberOfNumericConfig"->50,"Verbose"->True,"DoubleSquareRoots"->False,"ExtraPolynomials"->{1}}
RunEffortlessIndependent[SqrtList_,EvenAlpha_,SqrtRepl_,vars_,OptionsPattern[]]:=
Module[{oddList,independentoddList,CEvenAlpha=CheckInputEvenAlphaQ[EvenAlpha],IndependentOddLetters,sqrtList},
	If[!CEvenAlpha[[1]],
		CEvenAlpha[[2]],
		oddList=RunEffortless[SqrtList,EvenAlpha,SqrtRepl,vars,"ConstantCoefficientList"->OptionValue["ConstantCoefficientList"],"CheckNumberProducts"->OptionValue["CheckNumberProducts"],"CheckNumberLetters"->OptionValue["CheckNumberLetters"],"Range"->OptionValue["Range"],"Verbose"->OptionValue["Verbose"],"DoubleSquareRoots"->OptionValue["DoubleSquareRoots"],"ExtraPolynomials"->OptionValue["ExtraPolynomials"]];
		If[OptionValue["DoubleSquareRoots"]==True,sqrtList=Join[SqrtList,Table[SqrtList[[i]]SqrtList[[j]],{i,1,Length[SqrtList]},{j,i+1,Length[SqrtList]}]//Flatten],sqrtList=SqrtList];
		oddList=Table[oddList[[j]]//Table[Head[EvenAlpha[[1,1]]][sqrtList[[j]]][i]->#[[i]],{i,1,Length[#]}]&,{j,1,Length[oddList]}]//DeleteCases[#,{}]&;
		If[Length[Flatten[oddList]]==0,IndependentOddLetters={};,
		independentoddList=Table[FindIndependentLetters[oddList[[i]],SqrtRepl,vars,"NumberOfNumericConfig"->OptionValue["NumberOfNumericConfig"],"Verbose"->OptionValue["Verbose"],"CurrentSqrt"->sqrtList[[i]]],{i,1,Length[oddList]}];
		IndependentOddLetters=Flatten[independentoddList]/.Rule->List//Transpose//Last;];
		Print["Constructed "<>ToString[Length[Flatten[IndependentOddLetters]]]<>" independent odd letters."];
		IndependentOddLetters
		]
	]


Options[RunEffortlessIndependentFF]:={"ConstantCoefficientList"->{4},"CheckNumberProducts"->4,"CheckNumberLetters"->4,"Range"->1000,"Verbose"->True,"DoubleSquareRoots"->False,"ExtraPolynomials"->{1}}
RunEffortlessIndependentFF[SqrtList_,EvenAlpha_,SqrtRepl_,vars_,OptionsPattern[]]:=Module[{oddList,independentoddList,IndependentOddLetters,sqrtList},
	oddList=RunEffortless[SqrtList,EvenAlpha,SqrtRepl,vars,"ConstantCoefficientList"->OptionValue["ConstantCoefficientList"],"CheckNumberProducts"->OptionValue["CheckNumberProducts"],"CheckNumberLetters"->OptionValue["CheckNumberLetters"],"Range"->OptionValue["Range"],"Verbose"->OptionValue["Verbose"],"DoubleSquareRoots"->OptionValue["DoubleSquareRoots"],"ExtraPolynomials"->OptionValue["ExtraPolynomials"]];
	If[OptionValue["DoubleSquareRoots"]==True,sqrtList=Join[SqrtList,Table[SqrtList[[i]]SqrtList[[j]],{i,1,Length[SqrtList]},{j,i+1,Length[SqrtList]}]//Flatten],sqrtList=SqrtList];
	oddList=Table[oddList[[j]]//Table[Head[EvenAlpha[[1,1]]][sqrtList[[j]],i]->#[[i]],{i,1,Length[#]}]&,{j,1,Length[oddList]}]//DeleteCases[#,{}]&;
	independentoddList=Table[FindIndependentLettersFF[oddList[[i]],SqrtRepl,vars,"Verbose"->OptionValue["Verbose"],"CurrentSqrt"->sqrtList[[i]]],{i,1,Length[oddList]}];
	IndependentOddLetters=Flatten[independentoddList]/.Rule->List//Transpose//Last;
	Print["Constructed "<>ToString[Length[Flatten[IndependentOddLetters]]]<>" independent odd letters."];
	IndependentOddLetters
		]


Options[FindOddLetters]:={"ConstantCoefficient" -> 4,"CheckNumberProducts" -> 4,"Range"->1000};
FindOddLetters[CurrentSqrt_,AllowedEvenAlpha_,SqrtRepl_,vars_,OptionsPattern[]]:=
	Module[{ProdCoeff,odd,Poly},
		ProdCoeff=ConstructProducts[CurrentSqrt,AllowedEvenAlpha,SqrtRepl,vars,"ConstantCoefficient"->OptionValue["ConstantCoefficient"]];
		odd={};
		Do[
			If[AllowedProductQ[CurrentSqrt,CurrentProd,AllowedEvenAlpha,SqrtRepl,vars,"CheckNumberProducts"->OptionValue["CheckNumberProducts"],"Range"->OptionValue["Range"]],
				Poly=Sqrt[Factor[CurrentSqrt^2+CurrentProd/.SqrtRepl/.Flatten[AllowedEvenAlpha]]]//PowerExpand;
				AppendTo[odd,Log[(Poly-CurrentSqrt)/(Poly+CurrentSqrt)]];
				]
		,{CurrentProd,ProdCoeff}];
	odd];


Options[AllowedProductQ]:={"CheckNumberProducts" -> 4,"Range"->1000};
AllowedProductQ[CurrentSqrt_,Prod_,EvenAlpha_,SqrtRepl_,vars_,OptionsPattern[]]:=
	Module[{i,IntegerPoints,QQ=CurrentSqrt^2/.SqrtRepl,ProdExpl=Prod/.Flatten[EvenAlpha],point},
		IntegerPoints=Table[vars[[i]]->RandomInteger[{-OptionValue["Range"],OptionValue["Range"]}],{j,1,OptionValue["CheckNumberProducts"]},{i,1,Length[vars]}];
		And@@Table[IntegerQ[Sqrt[QQ+ProdExpl]/.point],{point,IntegerPoints}]
		];


Options[ConstructProducts]:={"ConstantCoefficient" -> 4};
ConstructProducts[CurrentSqrt_,AllowedEvenAlpha_,SqrtRepl_,vars_,OptionsPattern[]]:=
	If[Flatten[AllowedEvenAlpha]==={},{},
		Module[{\[Alpha]=Flatten[AllowedEvenAlpha][[1,1,0]],qPartitions,q,prodlist,Prod,PList,red,j},
			q=Max[Cases[CoefficientRules[CurrentSqrt^2/.SqrtRepl],v_?VectorQ:>Total[v],2]];
			Table[red[j]=AllowedEvenAlpha[[j]][[;;,1,1]],{j,1,Length[AllowedEvenAlpha]}];
			qPartitions=IntegerPartitions[q,All,Table[j,{j,1,Length[AllowedEvenAlpha]}]];
			prodlist=Table[Tuples[Table[red[entry],{entry,part}]],{part,qPartitions}]//Flatten[#,1]&;
			Prod=Times@@(Exp[\[Alpha][#]]&/@#)&/@prodlist;
			Join[OptionValue["ConstantCoefficient"] Prod,-OptionValue["ConstantCoefficient"] Prod]//DeleteDuplicates
			]
		];


FindAllZeroLocations[EvenAlpha_]:=
	Module[{},
			Table[entry[[1]]->If[((Max[Cases[CoefficientRules[Exp[entry[[2]]]],v_?VectorQ:>Total[v],2]]))<5,Solve[Exp[entry[[2]]]==0],{}],{entry,EvenAlpha}]
			];


Options[AllowedEvenLetters]:={"AllZeroLocations"->{},"CheckNumberLetters"->4,"Range"->1000};
AllowedEvenLetters[CurrentSqrt_,EvenAlpha_,SqrtRepl_,vars_,OptionsPattern[]]:=
	Module[{AllowedLetters={},QQ=CurrentSqrt/.SqrtRepl},
		Do[
			If[OptionValue["AllZeroLocations"]==={},
				If[AllowedLetterQ[QQ,Exp[entry[[2]]],vars,"CheckNumberLetters"->OptionValue["CheckNumberLetters"],"Range"->OptionValue["Range"]],
					AppendTo[AllowedLetters,entry];
					];,
				If[AllowedLetterQ[QQ,Exp[entry[[2]]],vars,"CheckNumberLetters"->OptionValue["CheckNumberLetters"],"Range"->OptionValue["Range"],"ZeroLocations"->entry[[1]]/.OptionValue["AllZeroLocations"]],
					AppendTo[AllowedLetters,entry];
					];];,	
			{entry,EvenAlpha}];
		If[AllowedLetters==={},{},SortAlphabetSublist[AllowedLetters,vars]]
		];


Options[AllowedLetterQ]:={"CheckNumberLetters"->4,"Range"->1000,"ZeroLocations"->{}}
AllowedLetterQ[QQ_,EvenLetter_,vars_,OptionsPattern[]]:=
	Module[{IntegerPoints,ZeroLocations,ValidTestQ},
		If[((Max[Cases[CoefficientRules[EvenLetter],v_?VectorQ:>Total[v],2]]))<5,
			IntegerPoints=Table[vars[[i]]->(-1)^RandomInteger[{1,2}]RandomInteger[{1,OptionValue["Range"]}],{j,1,OptionValue["CheckNumberLetters"]},{i,1,Length[vars]}];
			If[OptionValue["ZeroLocations"]==={},
				ZeroLocations=Solve[EvenLetter==0];,
				ZeroLocations=OptionValue["ZeroLocations"];
				];
			ValidTestQ=And@@#&/@(And[IntegerQ[Numerator[#]],IntegerQ[Denominator[#]]]&/@#&/@Flatten/@Transpose[Quiet[vars/.ZeroLocations/.IntegerPoints]]);
			ZeroLocations=Last/@DeleteCases[Transpose[{ValidTestQ,ZeroLocations}],{False,_}];
			And@@(Flatten[QQ/.ZeroLocations/.IntegerPoints]//And[IntegerQ[Numerator[#]],IntegerQ[Denominator[#]]]&/@#&),
			True]
		];


SortAlphabetSublist[EvenAlpha_,vars_]:=
	Module[{APOK=AlphabetPolynomialOrderKey[EvenAlpha,vars],MaxOrder,jj},
		MaxOrder=Max[APOK/.Rule->List//Transpose//Last];
		Table[Select[EvenAlpha,(#[[1]]/.APOK)==jj&],{jj,1,MaxOrder}]
		]


AlphabetPolynomialOrderKey[EvenAlpha_,vars_]:=
	Module[{jj},
		EvenAlpha//Table[#[[jj]]//(#[[1]]->(Max[Cases[CoefficientRules[Exp[#[[2]]]],v_?VectorQ:>Total[v],2]]))&,{jj,1,Length[EvenAlpha]}]&
		]


Options[FindIndependentLetters]:={"NumberOfNumericConfig"->50,"Verbose"->True,"CurrentSqrt"->{},"Range"->100}
FindIndependentLetters[NewLetters_,SqrtRepl_,vars_,OptionsPattern[]]:=Module[{list1,list2,decomp},
		list1=NewLetters; (* list of input log letters (to be added) *)
		list2={NewLetters[[1]]}; (* output, list of independent letters (can also be a list of already independent letters from previous analysis) *)

		For[kk=2,kk<=Length[list1],kk++,
			decomp=DecomposeInAlphabet[list2,list1[[kk]][[2]],SqrtRepl,vars,"NumberOfNumericConfig"->OptionValue["NumberOfNumericConfig"],"CurrentSqrt"->OptionValue["CurrentSqrt"],"Range"->OptionValue["Range"]];
			If[decomp===ELImpossible,AppendTo[list2,list1[[kk]]];If[OptionValue["Verbose"]==True,Print["New letter found at position ",kk," : ",list1[[kk]]]]]
			];
	list2
	]


Options[FindIndependentLettersFF]:={"Verbose"->True,"CurrentSqrt"->{}}
FindIndependentLettersFF[NewLetters_,SqrtRepl_,vars_,OptionsPattern[]]:=Module[{list1,list2,decomp},
		list1=NewLetters; (* list of input log letters (to be added) *)
		list2={NewLetters[[1]]}; (* output, list of independent letters (can also be a list of already independent letters from previous analysis) *)

		For[kk=2,kk<=Length[list1],kk++,
			decomp=DecomposeInAlphabetFF[list2,list1[[kk]][[2]],SqrtRepl,vars,"CurrentSqrt"->OptionValue["CurrentSqrt"]];
			If[decomp===ELImpossible,AppendTo[list2,list1[[kk]]];If[OptionValue["Verbose"]==True,Print["New letter found at position ",kk," : ",list1[[kk]]]]]
			];
	list2
	]


Options[DecomposeInAlphabet]:={"NumberOfNumericConfig"->50,"CurrentSqrt"->{},"Range"->100}
DecomposeInAlphabet[AlphabetRepl_,LetterToDecompose_,SqrtRepl_,vars_,OptionsPattern[]]:=Module[{c,ansatzabstract,ansatz,Dansatz, DansatzNlist,DansatzN,NumericList,sol,solution,Alphabet=Last/@AlphabetRepl,\[Alpha]=Head[First[First[AlphabetRepl]]]},
	ansatzabstract=Sum[c[i]AlphabetRepl[[i,1]], {i,1,Length[AlphabetRepl]}];
	Dansatz[var_]:=Dansatz[var]=Sum[c[i]TakeDerivativeOfLetterModSqrt[Alphabet[[i]],SqrtRepl,vars,var,"CurrentSqrt"->OptionValue["CurrentSqrt"]],{i,1,Length[Alphabet]}];
	Table[Dansatz[var];, {var,vars}];
	Do[NumericList=Table[var->RandomReal[OptionValue["Range"]],OptionValue["NumberOfNumericConfig"],{var,vars}];
		DansatzNlist[var_]:=DansatzNlist[var]=Dansatz[var]/.NumericList;Table[DansatzNlist[var];, {var,vars}];
		DansatzN=Table[Dansatz[var], {var,vars}]/.NumericList;sol[i]=Table[TakeDerivativeOfLetterModSqrt[LetterToDecompose,SqrtRepl,vars,var,"CurrentSqrt"->OptionValue["CurrentSqrt"]], {var,vars}]/.NumericList//NSolve[(#)==(DansatzN)]&;
	,{i,1,10}];
	solution=Table[sol[i],{i,1,10}]//Chop//Rationalize//DeleteDuplicates;
	If[solution=={{}}, ELImpossible,ansatzabstract/.Flatten[solution]]&//First
		]


Options[DecomposeInAlphabetFF]:={"CurrentSqrt"->{}}
DecomposeInAlphabetFF[AlphabetRepl_,LetterToDecompose_,SqrtRepl_,vars_,OptionsPattern[]]:=Module[{del,c,cSol,ansatzabstract,ansatz,Dansatz,DansatzNlist,DansatzN,NumericList,Alphabet=Last/@AlphabetRepl,\[Alpha]=Head[First[First[AlphabetRepl]]],EqSys},
	If[Needs["FiniteFlow`"]==$Failed,Print["FiniteFlow not found."]];
	ansatzabstract=Sum[c[i]AlphabetRepl[[i,1]], {i,1,Length[AlphabetRepl]}];
	Dansatz[var_]:=Dansatz[var]=Sum[c[i]TakeDerivativeOfLetterModSqrt[Alphabet[[i]],SqrtRepl,vars,var,"CurrentSqrt"->OptionValue["CurrentSqrt"]],{i,1,Length[Alphabet]}];
	EqSys=Sum[del[var]TakeDerivativeOfLetterModSqrt[LetterToDecompose,SqrtRepl,vars,var,"CurrentSqrt"->OptionValue["CurrentSqrt"]], {var,vars}]//(#)-(Sum[del[var]Dansatz[var],{var,vars}])&;
	cSol=FiniteFlow`FFLinearFit[{},EqSys,0,Join[vars,Table[del[var],{var,vars}],{}],Table[c[i],{i,1,Length[AlphabetRepl]}]];
	If[cSol===FiniteFlow`FFImpossible, Return[ELImpossible],ansatzabstract/.cSol]
		]


FactorOdd[OddLetter_,SqrtRepl_]:=
	Module[{expLett=Exp[OddLetter]},
	Numerator[expLett]Denominator[expLett]/.SqrtRepl//Expand//Factor
	]


Options[FactorOddInAlphabet]:={"NumberOfNumericConfig"->50,"Range"->100}
FactorOddInAlphabet[AlphabetRepl_,OddLetter_,SqrtRepl_,vars_,OptionsPattern[]]:=
	Module[{factoredOdd},
	factoredOdd=FactorOdd[OddLetter,SqrtRepl];
	DecomposeInAlphabet[AlphabetRepl,Log[factoredOdd],SqrtRepl,vars,"NumberOfNumericConfig"->OptionValue["NumberOfNumericConfig"],"Range"->OptionValue["Range"]]//Variables
	]


FactorOddInAlphabetFF[AlphabetRepl_,OddLetter_,SqrtRepl_,vars_]:=
	Module[{factoredOdd},
	factoredOdd=FactorOdd[OddLetter,SqrtRepl];
	DecomposeInAlphabetFF[AlphabetRepl,Log[factoredOdd],SqrtRepl,vars]//Variables
	]


TakeDerivativeOfLetter[Letter_,SqrtRepl_,vars_,var_]:=
	Module[{expLett,Q},
		expLett=Letter//Cases[#,Log[__],All]&//First//Exp;
		Q=expLett//Numerator//#/.ToRules[vars==0]&;
		If[Q===0,
			D[Letter,var],
			TakeDerivativeOfOdd[Letter,SqrtRepl,vars,var]
			]
		]


Options[TakeDerivativeOfLetterModSqrt]:={"CurrentSqrt"->{}}
TakeDerivativeOfLetterModSqrt[Letter_,SqrtRepl_,vars_,var_,OptionsPattern[]]:=
	Module[{expLett,Q},
		expLett=Letter//Exp;
		If[OptionValue["CurrentSqrt"]==={},Q=expLett//Numerator//#/.ToRules[vars==0]/.{-smth_->smth}&,Q=OptionValue["CurrentSqrt"]];
		If[Q===0,
			D[Letter,var],
			TakeDerivativeOfOddModSqrt[Letter,SqrtRepl,vars,var,Q]
			]
		]


TakeDerivativeOfOdd[Letter_,SqrtRepl_,vars_,x_,CurrentSqrt_]:=
	Module[{P,q,p},
		q=CurrentSqrt^2/.SqrtRepl;
		P=(Letter)//Exp//Numerator//#/.{CurrentSqrt->0}&;
		p=-(Letter//Exp//Numerator//(#-P)/CurrentSqrt&);
		(2 P q D[p,x]-2 q p D[P,x]+P p D[q,x])/(CurrentSqrt*(-P^2+q p^2))/.SqrtRepl//Together
		]


TakeDerivativeOfOddModSqrt[Letter_,SqrtRepl_,vars_,x_,CurrentSqrt_]:=
	Module[{P,q,p},
		q=CurrentSqrt^2/.SqrtRepl;
		P=(Letter)//Exp//Numerator//#/.{CurrentSqrt->0}&;
		p=-(Letter//Exp//Numerator//(#-P)/CurrentSqrt&);
		(2 P q D[p,x]-2 q p D[P,x]+P p D[q,x])/(-P^2+p^2 q)/.SqrtRepl//Together
		]


(*SortAlphabet[EvenAlpha_,vars_,head_:Global`\[Alpha]Lett]:=Module[{lett},SortBy[EvenAlpha,{(Exp[#[[2]]]//ResourceFunction["PolynomialDegree"][#,vars]&)&,#[[1,1]]&}]//Table[{head[j]->#[[j]][[1]],head[j]->#[[j]][[2]]},{j,1,Length[#]}]&//Transpose];*)
(*SortAlphabet[EvenAlpha_,vars_,head_:Global`\[Alpha]Lett]:=Module[{lett},
SortBy[EvenAlpha,{Max[Cases[CoefficientRules[Exp[#[[2]]]],v_?VectorQ:>Total[v],2]]&,#[[1,1]]&}]//Table[{head[j]->#[[j]][[1]],head[j]->#[[j]][[2]]},{j,1,Length[#]}]&//Transpose];*)


(* ::Section::Closed:: *)
(*Start of SOFIA*)


Print["Singularities of Feynman Integrals Automatized"]


Print[" ____   ___  _____ ___    _    
/ ___| / _ \\|  ___|_ _|  / \\   
\\___ \\| | | | |_   | |  / _ \\  
 ___) | |_| |  _|  | | / ___ \\ 
|____/ \\___/|_|   |___/_/   \\_\\"]


<<"GraphUtilities`"


(* ::Section::Closed:: *)
(*Lorentz rules and exterior algebra*)


Clear[Wedge,d,CenterDot]


SetAttributes[CenterDot,Orderless]


CenterDot/:CenterDot[x_+y_,z_]:=CenterDot[x,z]+CenterDot[y,z]
CenterDot/:CenterDot[c_*x_,y_]:=c CenterDot[x,y]/;NumericQ[c]
CenterDot/:CenterDot[0,y_]:=0
Protect[CenterDot];


wedgerules[arg_]:=arg//.wedge1//.wedge2
wedge1={
Wedge[u___,x_+y_,z___]:>Wedge[u,x,z]+Wedge[u,y,z],
Wedge[x___, (scalar_ :1)Wedge[y__],z___]:> scalar Wedge[x,y,z],
Wedge[x___,scalar_ d[z_],y___]:>scalar Wedge[x,d[z],y],
Wedge[u___,x_,z___]:>x Wedge[u,z]/;FreeQ[x,d[_]],
Wedge[d[x_]]:>d[x]
};
wedge2={
Wedge[u___,x_,y_,z___]:>-Wedge[u,y,x,z]/;Not@OrderedQ[{x,y}],
Wedge[u___,x_,y___,x_,z___]:>0
};
d/:d[x_+y_]:=d[x]+d[y]
d/:d[x_ d[y_]]:=Wedge[d[x],d[y]]
d/:d[(x_:1) Wedge[y__]]:=Wedge[d[x],y]
d/:d[d[x__]]:=0


Applyd[vars_]:={
d[x_]:>((Sum[D[x,vars[[i]]]d[vars[[i]]],{i,1,Length[vars]}]))
};


(* ::Section::Closed:: *)
(*n-point kinematics*)


(*write _\[CenterDot]_ in the cyclic basis of Mandelstam invariants:*)
Clear[GenerateKinematics]
GenerateKinematics[nParticles_]:=
If[nParticles==2,{Subscript[p, 1]\[CenterDot]Subscript[p, 1]->s},Module[{out},
n=nParticles;
(* Matrix of Subscript[p, i]\[CenterDot]Subscript[p, j] invariants we want to express in terms of Subscript[s, I]'s and Subscript[M, i]'s *)
ppMatrix=Table[If[i==j,Subscript[M, i]^2,(Subscript[s, Sequence@@Sort[{i,j}]]-Subscript[M, i]^2-Subscript[M, j]^2)/2],{i,n},{j,n}];
(* Cyclic basis of Mandelstam invariants Subscript[s, I] where I is a cyclic permutation of up to n/2 labels *)
cyclicBasis=Flatten[Table[Subscript[s, Sequence@@Sort[Mod[Range[a,a+l],n,1]]],{l,1,n/2-1},{a,If[l==n/2-1,n/2,n]}]];
(* Relations for expressing the cyclic basis Subscript[s, I] in terms of Subscript[s, i,j] *)
sRelations=Flatten[Table[Subscript[s, Sequence@@Sort[Mod[Range[a,a+l],n,1]]]==Sum[ppMatrix[[b,c]],{b,Mod[Range[a,a+l],n,1]},{c,Mod[Range[a,a+l],n,1]}],{l,1,n/2-1},{a,If[l==n/2-1,n/2,n]}]];
(* Momentum conservation *)
momentumConservation=Table[Sum[ppMatrix[[i,j]],{j,n}]==0,{i,n}];
(* Solve for the momentum conservation and the Mandelstam relations *)
solution=Solve[
Join[momentumConservation,sRelations]
,Complement[Variables[ppMatrix],cyclicBasis,Table[Subscript[M, i],{i,n}]]][[1]];
(* Print the output as a list of substitutions *)
substitutions=Flatten[Table[Subscript[p, i]\[CenterDot]Subscript[p, j]->ppMatrix[[i,j]]/.solution//Factor,{i,n},{j,n}]];
out=substitutions
]
]


(* ::Section::Closed:: *)
(*Feynman diagramatic *)


FeynmanDraw:=Module[{edgelist,edgelist2,extnodes,posnodes,nodes0,edgelist3,vertices,ivertices,reordering,intmasses,allEdges,nodes1,edgelistfinal,edges,nodes},
edgelist=GraphEdit[][[2,2]];
edgelist2=Partition[ToExpression[StringReplace[ToString[edgelist],"->"-> ","]],2];
extnodes=Select[Tally[Flatten[edgelist2]],#[[2]]==1&]//Transpose//First;
posnodes=(Position[edgelist2,#][[1]]&/@extnodes)/.{{x_,1}->{x,2},{x_,2}->{x,1}};
nodes0=Sort[Table[Part[edgelist2,posnodes[[n,1]],posnodes[[n,2]]],{n,1,Length[extnodes]}]];
edgelist3=Sort/@Delete[edgelist2,List/@(posnodes//Transpose//First)];
vertices=edgelist3//Flatten//DeleteDuplicates;
ivertices=Complement[vertices,nodes0];
nodes1=nodes0//DeleteDuplicates;
reordering=Join[Table[nodes1[[i]]->i,{i,1,Length[nodes1]}],Table[ivertices[[i]]->i+Length[nodes1],{i,1,Length[ivertices]}]];
edgelistfinal=Sort/@(edgelist3/.reordering);
edges=Table[{edgelistfinal[[i]],Subscript[m, i]^2},{i,1,Length[edgelistfinal]}];
nodes=Table[{Part[nodes0/.reordering,i],Subscript[M, i]},{i,1,Length[nodes0]}];
{edges,nodes}]


FeynmanPlot[x_]:=FeynmanPlot[x[[1]],x[[2]]];
FeynmanPlot[edgesin_,nodesin_]:=Module[{edges,nodes,edgelist,vertices,intmasses,extmasses,vmax,masslessedges,masslesspos,vmasslesspos,allEdges,multiplicity,graph0,edgelistgraph,graph,ContactQ},
ContactQ=SameQ[edgesin,{}];(* True if it's a contact diagram *);
If[ContactQ, {edges={},nodes=nodesin},(*checks the trivial case of contact diagrams *)
If[Length[Part[Flatten/@edgesin,1]]==3,{edges=edgesin,nodes=nodesin}, {nodes=edgesin,edges=nodesin}](* corrects arguments if they were swapped by mistake*);];
edgelist=Sort/@(#[[1]]&/@edges);
vertices=If[ContactQ,{1},Sort[DeleteDuplicates[Flatten[edgelist]]]];
intmasses=PowerExpand[Sqrt[#[[2]]]]&/@edges;
extmasses=#[[2]]&/@nodes;
vmax=vertices[[-1]];
masslesspos=Position[Join[intmasses,extmasses],0]//Flatten;
vmasslesspos=(Position[extmasses,0]//Flatten)+vmax;
allEdges=#[[1]]\[UndirectedEdge]#[[2]]&/@Join[edgelist,Table[{nodes[[v,1]],vmax+v},{v,Length[nodes]}]];
multiplicity=Sort[Transpose[Tally[allEdges]][[2]]][[-1]];
graph0=EdgeTaggedGraph[Join[vertices,Range[vmax+1,vmax+Length[nodes]]],allEdges];
edgelistgraph=EdgeList[graph0];
masslessedges=Part[edgelistgraph,masslesspos];
graph=EdgeTaggedGraph[Join[vertices,Style[#,Transparent]&/@Range[vmax+1,vmax+Length[nodes]]],allEdges,EdgeWeight->Thread[edgelistgraph->Join[Style[#,Black,Background->White]&/@intmasses,ConstantArray[Style[1,Transparent],Length[allEdges]-Length[intmasses]]]],VertexWeight->Join[vertices,nodes[[All,2]]]];
GraphPlot[graph,EdgeLabels ->Thread[Complement[edgelistgraph,masslessedges]->"EdgeWeight"],VertexLabels->Join[Thread[Complement[VertexList[graph0],vmasslesspos]->"VertexWeight"],Thread[vmasslesspos->""]],MultiedgeStyle->0.22*(multiplicity-1),
PlotTheme->"Scientific",PlotRangePadding->Scaled[0.2],GraphLayout->"SpringElectricalEmbedding",
EdgeStyle->Thread[masslessedges->Dashed]]
]


(* Contracts selected edge: edgein = {a,b} || {b,a} || {{a,b},Subscript[m, i]^2} || {{b,a},Subscript[m, i]^2} *)
ContractEdge[edgenode_,edgein_]:=Module[{edgect,edgelist,posedgect,newedges,newnodes,edges0,edges,nodes},
edges0=edgenode[[1]]; nodes=edgenode[[2]];
edges={Sort/@Transpose[edges0][[1]],Transpose[edges0][[2]]}//Transpose; (* sorts them correctly *);
edgelist=Sort/@edges[[All,1]];
If[Depth[edgein]==2,
edgect=Sort[edgein];posedgect=(Position[edgelist,edgect]//Flatten)[[1]];,
edgect={Sort[edgein[[1]]],edgein[[2]]};posedgect=(Position[edges,edgect]//Flatten)[[1]];];
newedges=Delete[edges,posedgect]//.{{x_,edgelist[[posedgect,2]]}->{x,edgelist[[posedgect,1]]},{edgelist[[posedgect,2]],x_}->{edgelist[[posedgect,1]],x}};
newnodes=nodes/.{{edgelist[[posedgect,2]],x_}->{edgelist[[posedgect,1]],x}};
{newedges,newnodes}]

(* Lists all single edge contractions *)
ContractSingle[edgenode_]:=Table[ContractEdge[edgenode,edgenode[[1,j]]],{j,1,Length[edgenode[[1]]]}]

(* lists all contractions *)
Contractions[edgenode_]:=Module[{contractions,j,max},
max=Length[edgenode[[1]]];
For[j=0;contractions[0]={edgenode},j<=max,j++,
contractions[j+1]=Table[ContractSingle[contractions[j][[i]]],{i,1,contractions[j]//Length}]//Flatten[#,1]&];
Table[contractions[j],{j,0,max}]//Flatten[#,1]&//DeleteDuplicates
]

NLoops[edgenode_]:= Module[{edges,edgelist},
edges=Transpose[edgenode[[1]]][[1]]//Quiet;
If[SameQ[edges,{}[[1]]]//Quiet,0,
edgelist=#[[1]]\[UndirectedEdge]#[[2]]&/@edges;
FindFundamentalCycles[edgelist]//Length]]


(* Remove unwanted graphs: *)
NVertexCut[edgenode_]:= Module[{edges},
edges=Transpose[edgenode[[1]]][[1]]//Quiet;
If[SameQ[edges,{}[[1]]]//Quiet,0,
edgelist=#[[1]]\[UndirectedEdge]#[[2]]&/@edges;
FindVertexCut[edgelist]//Length]]
OneVertexIrreducibleQ[edgenode_]:=If[NVertexCut[edgenode]>1,True,If[VertexCount[edgelist]>2,False,True]]
NoTadpoleQ[edgenode_]:=If[SameQ[Select[edgenode[[1]],SameQ[#[[1,1]],#[[1,2]]]&],{}],True,False]
NotContactQ[edgenode_]:=If[SameQ[edgenode[[1]],{}],False,True]
ContractionsNontrivial[edgenode_]:=Select[Select[Contractions[edgenode],OneVertexIrreducibleQ[#]&&NoTadpoleQ[#]&&NotContactQ[#]&],SameQ[NLoops[#],NLoops[edgenode]]&]


(* ::Section::Closed:: *)
(*Mathematica solvers*)


MyFactorList[list_]:=Select[DeleteDuplicates[Flatten[Map[FactorList[#][[All,1]]&,list]]],!NumericQ[#]&]


myPolynomialDecomposition[P_,vars_List]:=Module[{cr,monomials,coeffs},
cr=CoefficientRules[P,vars];
monomials=Map[Apply[Times,MapThread[#1^#2&,{vars,#}]]&,First/@cr];
coeffs=Last/@cr;
{coeffs,monomials}]


(* to improve speed: *)
generateAnsatzDISPATCH[gramList_,active_,dummyVAR_]:=Module[{},
Clear[ansatz0,fixCoeffs];
ansatz0=Table[#[[ii]] . Array[dummyVAR[ii],Length[#[[ii]]]],{ii,Length[#]}]&[myPolynomialDecomposition[#,active][[2]]&/@gramList];
fixCoeffs=Dispatch[Flatten[Table[Thread[Array[dummyVAR[ii],Length[#[[ii]]]]->#[[ii]]],{ii,Length[#]}]&[myPolynomialDecomposition[#,active][[1]]&/@gramList]]];
Return[{ansatz0,fixCoeffs}];
]
discriminant[poly_,var_,p_:0,dummyVAR_]:=Module[{out,tempf},
tempf=QuietEcho[generateAnsatzDISPATCH[{#1},{var},dummyVAR]]&[poly];
out=Discriminant[tempf[[1]][[1]],var,Method->"Subresultants",Modulus->p]/.tempf[[2]];
Return[out];
]
resultant[poly1_,poly2_,var_,p_:0,dummyVARLIST_List]:=Module[{out,tempf1,tempf2},
tempf1=QuietEcho[generateAnsatzDISPATCH[{#1},{var},dummyVARLIST[[1]]]]&[poly1];
tempf2=QuietEcho[generateAnsatzDISPATCH[{#1},{var},dummyVARLIST[[2]]]]&[poly2];
out=Resultant[tempf1[[1]][[1]],tempf2[[1]][[1]],var,Method->"Subresultants",Modulus->p]/.tempf1[[2]]/.tempf2[[2]];
Return[out];
]


(* Checks whether two polynomials are equal up to an overall constant -- probabilistic version *)
ProportionalPolynomialsQ[poly1_, poly2_, checks_ : 5, p_ : 0] := 
  Module[{vars, i},
   If[Length[poly1] != Length[poly2], Return[False]];
   vars = Variables[poly1];
   If[Variables[poly2] =!= vars, Return[False]];
   Return[CountDistinct[Table[
       ((If[p > 0, Mod[#, p], #] & /@ (poly1^2 + 1))/
            (If[p > 0, Mod[#, p], #] & /@ (poly2^2 + 
            1))) /. ((# -> RandomInteger[{1, 10^2}]) & /@ vars)
       , {i, checks}]] == 1];
   ];


(* Implementation of the Fubini reduction *)
(* This version is based on Remark 71 from https://arxiv.org/abs/0910.0114 *)
(* It runs Fubini[...] for different orderings and intersects the results on the fly *)
(**)
(* Input: *)
(* polynomials = list of polynomials to reduce *)
(* variables = variables to be eliminted; the order matters *)
(* limit = upper bound on the number of terms in a polynomial at the intermediate stage of the reduction; higher values give more accurate results but are slower to compute (default: 100) *)
(* p = finite field prime; p=0 means not using finite fields (default: 0) *)
(* FactorLast = whether to factor polynomials in the last stage of the reduction (default: True) *)
(**)
(* Output: *)
(* list of irreducible polynomials resulting from the Fubini reduction *)
FastFubini[polynomials_List,variables_List,limit_Integer:100,p_Integer:0,FactorLast_:True]:=Module[{set,freePolynomials,preSTable,preS,size,vars},

(* The initial set Subscript[S, []] *)
set[{}]=polynomials;

(* Separately, keep track of the polynomials that do not depend on any variable *)
freePolynomials={};

(* Iterate over every subset of variables in the order of increasing size *)
(* vars = current ordering under consideration *)
(* size = size of vars *)
Monitor[Do[

(* Compute the reduction Subscript[(Subscript[S, vars\v]), v] for every variable v in vars, by taking the previous result for vars\v and eliminating v *)
preSTable=Table[Fubini[set[Sort[Complement[vars,{v}]]],{v},limit,p,FactorLast],{v,vars}];

(* Intersect the results, Subscript[S, vars] = \!\(
\*SubscriptBox[\(\[Intersection]\), \(v \[Element] vars\)]\ \(SubscriptBox[\((SubscriptBox[S, vars\\v])\), v]\)\) *)
preS=Apply[Intersection[##,SameTest->(ProportionalPolynomialsQ[#1,#2,3,p]&)]&,preSTable];

(* Keep only the polynomials that depend on variables *)
(* Those that do not are saved in freePolynomials for later *)
set[Sort[vars]]=Table[
If[Intersection[variables,Variables[f]]==={},
freePolynomials=Append[freePolynomials,f];Nothing,f]
,{f,preS}];

,{size,Length[variables]},{vars,Subsets[variables,{size}]}],vars];

(* Return the intersection of Subscript[S, variables] and the polynomials we saved *)
Return[DeleteDuplicates[Join[set[Sort[variables]],freePolynomials],ProportionalPolynomialsQ[#1,#2,3,p]&]];

];


(* Implementation of the Fubini reduction for a single ordering of variables *)
(**)
(* Input: *)
(* polynomials = list of polynomials to reduce *)
(* variables = variables to be eliminted; the order matters *)
(* limit = upper bound on the number of terms in a polynomial at the intermediate stage of the reduction; higher values give more accurate results but are slower to compute (default: 100) *)
(* p = finite field prime; p=0 means not using finite fields (default: 0) *)
(* FactorLast = whether to factor polynomials in the last stage of the reduction (default: True) *)
(**)
(* Output: *)
(* list of irreducible polynomials resulting from the Fubini reduction *)
Fubini[polynomials_List,variables_List,limit_Integer:100,p_Integer:0,FactorLast_:True]:=Module[{Snew,degrees,terms,term1,term2,var,f},

Snew=polynomials;

Monitor[Do[

degrees=Table[Length[CoefficientList[ss,var]]-1,{ss,Snew}];
terms=Table[Length[ss],{ss,Snew}];

term1=Flatten[Table[
{CoefficientList[f,var][[-1]],
If[FreeQ[f,var],Nothing,If[Length[f]>limit,Nothing,discriminant[f,var,p,cc0]]]}
,{f,Snew}]];

term2=Flatten[Table[If[FreeQ[Snew[[ii]],var]||FreeQ[Snew[[jj]],var]||Length[Snew[[ii]]]>limit||Length[Snew[[jj]]]>limit,Nothing,
resultant[Snew[[ii]],Snew[[jj]],var,p,{cc1,cc2}]]
,{ii,Length[Snew]},{jj,ii+1,Length[Snew]}]];

Snew=
If[SameQ[FactorLast,False],
If[SameQ[var,variables[[-1]]],
Select[
Join[term1,term2]
,Not[NumericQ[#]]&],
Select[
DeleteDuplicates[Flatten[Map[FactorList[#,Modulus->p][[All,1]]&,Join[term1,term2]]]]
,Not[NumericQ[#]]&]
],
Select[
DeleteDuplicates[Flatten[Map[FactorList[#,Modulus->p][[All,1]]&,Join[term1,term2]]],ProportionalPolynomialsQ[#1,#2,10,p]&]
,Not[NumericQ[#]]&]
];

,{var,variables}],{var,degrees,terms}];

Return[Snew];
];

(* Running version of Fubini which prints partial results as we consider more and more orderings *)
RunningFubini[S_,vars2_,limit_:8,p_:0,FactorLast_:True]:=Module[{permutations,runningResult,current,perm},

permutations=RandomSample[Permutations[vars2]];
runningResult=Nothing;

Monitor[Do[

Echo[perm,"Checking ordering"];

current=FastFubini[S,perm,limit,p,FactorLast];
runningResult=If[runningResult===Nothing,
current,
Intersection[runningResult,current,SameTest->(ProportionalPolynomialsQ[#1,#2,10,p]&)]];
,{perm,permutations}],runningResult];

Return[runningResult];
];

BrownPanzer[polynomials_,variables_,limit_:100,p_:0,FactorLast_:True]:=Module[{f,debug,S,CC,var,degrees,graph,ss,preS,compatible,i,j,k,uniqueS,uniqueC,triples,pair1,pair2,triple},

debug=False;

(* Initialize the sets S and C *)
S[0]=polynomials;
CC[0]=Subsets[Range[Length[S[0]]],{2}];

If[debug,
Echo[S[0],"S[0] = "];
Echo[CC[0],"C[0] = "];
];

(* Loop over the variables in order *)
Monitor[Do[


var=variables[[i]];(* Current variable to be eliminated *)
degrees=Table[Length[CoefficientList[ss,var]]-1,{ss,S[i-1]}]; (* Degrees of the polynomials (for printing only) *)
graph=Graph[CC[i-1],VertexLabels->Table[i->degrees[[i]],{i,Length[degrees]}]];

If[debug,
Echo[var,"var ="];
];

(* Collect all irreducible factors from three sources: Res(f,g), Disc(f), Res(f,0) *)
preS=Join[

(* [f,g] *)
Table[
If[Or[Length[CoefficientList[S[i-1][[compatible[[1]]]],var]]-1>limit,Length[CoefficientList[S[i-1][[compatible[[2]]]],var]]-1>limit]
,Nothing,
{(*FactorList[resultant[S[i-1][[compatible[[1]]]],S[i-1][[compatible[[2]]]],var,p,{cc1,cc2}],Modulus->p][[2;;,1]]*)
If[SameQ[FactorLast,False],
If[SameQ[var,variables[[-1]]],
resultant[S[i-1][[compatible[[1]]]],S[i-1][[compatible[[2]]]],var,p,{cc1,cc2}],
FactorList[resultant[S[i-1][[compatible[[1]]]],S[i-1][[compatible[[2]]]],var,p,{cc1,cc2}],Modulus->p][[2;;,1]]],
FactorList[resultant[S[i-1][[compatible[[1]]]],S[i-1][[compatible[[2]]]],var,p,{cc1,cc2}],Modulus->p][[2;;,1]]
],
compatible}]
,{compatible,CC[i-1]}],

(* [f,f'] *)
Table[If[FreeQ[S[i-1][[j]],var],Nothing,
If[Length[CoefficientList[S[i-1][[j]],var]]-1>limit,
Nothing,
{(*FactorList[discriminant[S[i-1][[j]],var,p,cc0],Modulus->p][[2;;,1]]*)
If[SameQ[FactorLast,False],
If[SameQ[var,variables[[-1]]],
discriminant[S[i-1][[j]],var,p,cc0],
FactorList[discriminant[S[i-1][[j]],var,p,cc0],Modulus->p][[2;;,1]]],
FactorList[discriminant[S[i-1][[j]],var,p,cc0],Modulus->p][[2;;,1]]
],
{\[Infinity],j}}]
],{j,Length[S[i-1]]}],

(* [f,\[Infinity]] *)
Table[
If[Length[CoefficientList[S[i-1][[j]],var]]-1>limit,Nothing,
{(*FactorList[CoefficientList[S[i-1][[j]],var][[-1]],Modulus->p][[2;;,1]]*)
If[SameQ[FactorLast,False],
If[SameQ[var,variables[[-1]]],
CoefficientList[S[i-1][[j]],var][[-1]],
FactorList[CoefficientList[S[i-1][[j]],var][[-1]],Modulus->p][[2;;,1]]],
FactorList[CoefficientList[S[i-1][[j]],var][[-1]],Modulus->p][[2;;,1]]
],
{j,j}}]
,{j,Length[S[i-1]]}]

];

(* Lists of unique irreducible factors in the new S and the pairs of polynomials they came from *)
uniqueS=Select[DeleteDuplicates[Flatten[preS[[All,1]]],ProportionalPolynomialsQ[#1,#2,10,p]&],Not[NumericQ[#]]&];
uniqueC=Table[DeleteDuplicates[Cases[preS,{{___,f,___},_}][[All,2]]],{f,uniqueS}];

If[debug,
Echo[preS,"preS = "];
Echo[uniqueS,"uniqueS = "];
Echo[uniqueC,"uniqueC = "];
Echo[triples,"triples"];
];

If[debug,
Echo[Length[CC[i-1]],"len = "];
];
(* List of all triangles in the graph C[i-1] *)
(*triples=DeleteDuplicates[Select[Sort/@DeleteDuplicates/@Flatten/@Subsets[Join[CC[i-1],Table[{\[Infinity],j},{j,Length[S[i-1]]}]],{3}],Length[#]==3&]];*)

(* Construct the lists S[i] and C[i] for the next step *)
S[i]=uniqueS;
CC[i]={};

Do[

(* A pair of polynomials in S[i] is compatible only if it came from two edges in a triangle in C[i], or if it came from a single discriminant *)
(*If[
Or@@Flatten[Table[
Or[And[Length[Intersection[pair1,triple]]==2,Length[Intersection[pair2,triple]]==2],
And[Length[DeleteDuplicates[pair1]]==1,pair1==pair2]],
{pair1,uniqueC[[j]]},{pair2,uniqueC[[k]]},{triple,triples}]],
CC[i]=Append[CC[i],{j,k}]
];*)

(* TODO currently it's missing {i,\[Infinity]}, {i,\[Infinity]} -> check if {i,j},{j,\[Infinity]} exisits*)

Do[

If[(* pair1 = pair2 = {i,j} and i,j != \[Infinity] 
or pair1 = pair2 = {i,\[Infinity]} and {i,j} exists in CC[i-1] for any j *)
pair1===pair2,
If[Count[pair1,\[Infinity]]==0,
CC[i]=Append[CC[i],{j,k}];
Break[];
,
If[Count[CC[i-1],{Complement[pair1,{\[Infinity]}][[1]],_}]>0||Count[CC[i-1],{_,Complement[pair1,{\[Infinity]}][[1]]}]>0,
CC[i]=Append[CC[i],{j,k}];
Break[];
];
];
];

union=Union[pair1,pair2];
intersection=Intersection[pair1,pair2];
complement=Complement[union,intersection];

If[(* pair1 = {i,j}, pair2 = {j,k} (all i,j,k distinct) => check if {i,k} exists in CC[i-1] or if any i,k === \[Infinity] *)
Length[union]==3&&Length[intersection]==1&&Or[Count[complement,\[Infinity]]>0,Count[CC[i-1],Sort[complement]]>0],
CC[i]=Append[CC[i],{j,k}];
Break[];
];
,{pair1,uniqueC[[j]]},{pair2,uniqueC[[k]]}];

,{j,Length[uniqueS]},{k,j+1,Length[uniqueS]}];

(* TODO overwritting!!!! *)
(*CC[i]=Subsets[Range[Length[S[i]]],{2}];*)

If[debug,
Echo[S[i],"newS = "];
Echo[CC[i],"newC = "];
];

,{i,Length[variables]}],{variables[[i]],degrees,graph}];

Return[S[Length[variables]]];

];

RunningBrownPanzer[S_,vars2_,limit_:100,p_:0,FactorLast_:True]:=Module[{permutations,runningResult,current,perm,intersection},

permutations=RandomSample[Permutations[vars2]];
runningResult=Nothing;

Monitor[Do[

Echo[perm,"Checking ordering"];

current=BrownPanzer[S,perm,limit,p,FactorLast];

runningResult=If[runningResult===Nothing,
current,
intersection=Intersection[runningResult,current,SameTest->(ProportionalPolynomialsQ[#1,#2,10,p]&)];
If[Length[runningResult]>Length[intersection],
Echo[Length[runningResult]-Length[intersection],"Polynomials eliminated:"]];
intersection];

,{perm,permutations}],runningResult];

Return[runningResult];
];


(* ::Section:: *)
(*Choosing loop edges*)


(*Writing a new version from scratch:*)
normalizeEdge[UndirectedEdge[a_,b_,w_]]:=UndirectedEdge[Min[a,b],Max[a,b],w];
FirstUniqueOnePositions[matrix_]:=Module[{trimmed,zeroCols,positions},
trimmed=matrix[[All,1;;-2]];
zeroCols=Position[Total[trimmed,{1}],1][[All,1]];
positions=Table[SelectFirst[Range[Length[trimmed[[i]]]],MemberQ[zeroCols,#]&&trimmed[[i,#]]==1&],{i,Length[trimmed]}];
positions];
addedges[edges_]:=Cases[Tally[Flatten[edges],Sort[#1]===Sort[#2]&],{e_,_?OddQ}:>e];
FixLoopEdges[edgesnodes_]:=QuietEcho[Module[{cycles0Prime,rememberCycles0,OUT,TT,intoOUT,temp1,temp2,basis,edgesin,nodesin,pos,cycles0,(*cycles1, cycles2, cycles3,*)cycles(*,OUT*),edges,nodes,edgelist,vertices,intmasses,extmasses,vmax,masslessedges,masslesspos,vmasslesspos,allEdges,multiplicity,graph0,edgelistgraph,graph,ContactQ},
edgesin=edgesnodes[[1]];
nodesin=edgesnodes[[-1]];
ContactQ=SameQ[edgesin,{}];
If[ContactQ, {edges={},nodes=nodesin},
If[Length[Part[Flatten/@edgesin,1]]==3,{edges=edgesin,nodes=nodesin}, {nodes=edgesin,edges=nodesin}];];
edgelist=Sort/@(#[[1]]&/@edges);
vertices=If[ContactQ,{1},Sort[DeleteDuplicates[Flatten[edgelist]]]];
intmasses=PowerExpand[Sqrt[#[[2]]]]&/@edges;
extmasses=#[[2]]&/@nodes;
vmax=vertices[[-1]];
masslesspos=Position[Join[intmasses,extmasses],0]//Flatten;
vmasslesspos=(Position[extmasses,0]//Flatten)+vmax;
allEdges=#[[1]]\[UndirectedEdge]#[[2]]&/@Join[edgelist,Table[{nodes[[v,1]],vmax+v},{v,Length[nodes]}]];
multiplicity=Sort[Transpose[Tally[allEdges]][[2]]][[-1]];
graph0=EdgeTaggedGraph[Join[vertices,Range[vmax+1,vmax+Length[nodes]]],allEdges];
edgelistgraph=EdgeList[graph0]//Echo;
pos=FirstUniqueOnePositions[
First[MinimalBy[{
SortBy[Map[Append[#,Total[#]]&,Mod[RowReduce[Normal[EdgeCycleMatrix[edgelistgraph]]],2]],Last],
SortBy[Map[Append[#,Total[#]]&,Normal[EdgeCycleMatrix[edgelistgraph]]],Last]
},Total[#[[All,-1]]]&]]
];
Return[pos];
]]


(* ::Section::Closed:: *)
(*Helper functions for Baikov*)


(*To time functions dynamically*)
SetAttributes[timed,HoldAll]
timed[expr_]:=With[{start=AbsoluteTime[]},PrintTemporary@Dynamic[Row[{"Time elapsed: ",AbsoluteTime[]-start}],UpdateInterval->0.1];
expr]


(* Routine to extract all minors: *)
ClearAll[listMinors];
listMinors[M_]:=Module[{n=Dimensions[M][[1]],combs,minorsOfSize,allMinors,extractSubmatrix},
combs[list_,size_]:=Subsets[list,{size}];
extractSubmatrix[rows_,cols_]:=M[[rows,cols]];
minorsOfSize[size_]:=Module[{rowCombs,colCombs,subMs},rowCombs=combs[Range[n],size];
colCombs=combs[Range[Dimensions[M][[2]]],size];
toPrint=Flatten[Table[MatrixForm[extractSubmatrix[rowCombs[[i]],colCombs[[j]]]],{i,Length[rowCombs]},{j,Length[colCombs]}],1];
Echo[toPrint];
subMs=Flatten[Table[Det[extractSubmatrix[rowCombs[[i]],colCombs[[j]]]],{i,Length[rowCombs]},{j,Length[colCombs]}],1];
subMs];
allMinors=Table[minorsOfSize[size],{size,1,Min[n,Dimensions[M][[2]]]}];
allMinors]
(* Routine to excise rows and column: *)
ExciseRowsColumns[matrix_,rowsToDelete_,colsToDelete_]:=Module[{rows,cols},rows=Delete[matrix,List/@rowsToDelete];
cols=Transpose[Delete[Transpose[rows],List/@colsToDelete]];
cols]


(* Function to extract Subscript[a,i] symbols: *)
extractAis[expr_]:=DeleteDuplicates[Cases[expr,Subscript[a,_],{0,Infinity}]];
(*Filter list*)
filteredList[list_]:=Module[{seenAis={}},Select[list,Function[entry,With[{aTerms=extractAis[entry[[2]]]},If[DisjointQ[seenAis,aTerms],AppendTo[seenAis,#]&/@aTerms;True,False]]]]];


(* Upper bound on the number of loop-by-loop Baikov variables: *)
nlbl[loop_,listE_]:=loop+(Plus@@listE)


(* Rule to automatically homogeneize the kinematic: *)
homogeneizeKin[arg_]:=arg//.Subscript[s, a___]:>ToExpression["s"<>StringJoin[ToString/@{a}]]//.Subscript[M, i_]:>Sqrt[ToExpression["MM"<>ToString[i]]]//.Subscript[m, i_]:>Sqrt[ToExpression["mm"<>ToString[i]]]//.M:>Sqrt[MM]//.m:>Sqrt[mm]


(* ::Section::Closed:: *)
(*SOFIABaikov*)


(* Function that will look for a rank drop: *)
rankDropRule[OUT_]:=Module[{},
temp1=#[[1]]&/@OUT;
numTemp=Thread[#->(#1[[1]]/#1[[-1]]&/@RandomChoice[Subsets[DeleteDuplicates[RandomPrime[{5,10000},1000]],{2}],Length[#]])]&[Variables[temp1]];
temp2=NullSpace/@(temp1//.numTemp);
temp3=Table[If[SameQ[temp2[[ii]],{}],
{},
Subsets[#[[1]],{#[[-1]]}]&[{DeleteDuplicates[Flatten[#]],Length[#]}&[
SparseArray[#]["NonzeroPositions"]&/@temp2[[ii]]]]
]
,{ii,Length[temp2]}];
temp4=If[Length[#1]>0,First[Flatten[SparseArray[#1]["NonzeroPositions"]]],NONE]&/@Table[
Factor[Det[ExciseRowsColumns[(temp1//.numTemp)[[ii]],temp3[[ii]][[jj]],temp3[[ii]][[jj]]]]]
,{ii,Length[temp3]},{jj,Length[temp3[[ii]]]}];
temp5=Table[
If[
SameQ[temp4[[ii]],NONE],
Echo["NO rank drop detected for matrix: "<>ToString[ii]<>""];temp1[[ii]],
Echo["Rank drop detected for matrix: "<>ToString[ii]<>""];ExciseRowsColumns[temp1[[ii]],temp3[[ii]][[temp4[[ii]]]],temp3[[ii]][[temp4[[ii]]]]]
]
,{ii,Length[temp4]}];
(*Check:*)
If[ContainsAny[Simplify[Det/@(temp5//.numTemp)],{0}],Echo[Style["Something is wrong: some matrices still not have full rank. You should probably reconsider the input of loop edges.",Red]],Echo[Style["All matrices have full rank!",Blue]]];
Return[MatrixForm/@temp5];
]


(* Function that should find a loop momenta shift minimizing the number of Baikov (integration) variables.
The idea behind the code is simple: the code performs a linear shift in the loop momenta and finds (if any) a non-trivial solution to this shift that eliminates as many scalar products as possible.*)
FindLoopMomShift[AllEliminate\[CapitalLambda]_]:=Module[{},
seed=Select[AllEliminate\[CapitalLambda]/.Subscript[l, i_]:>Subscript[l, i]+Subscript[a, i],!FreeQ[#,Subscript[l, _]]&];
tab=DeleteCases[Table[#[[1]]&/@Position[seed,Subscript[a, ii]],{ii,noLoops}],{}];
pos[0]=tab[[1]];
Do[
pos[ii]=DeleteCases[tab[[ii]],Alternatives@@Flatten[Table[tab[[jj-1]],{jj,ii}]]],
{ii,Length[tab]}];
foo1=seed[[Flatten[Table[pos[ii],{ii,Length[tab]}]]]]//.Rule[a_,b_]:>b;
foo2=(#[[1]]&/@(Cases[#,Subscript[l, _],Infinity]&/@foo1))-foo1;
aShift=If[SameQ[#,{}],
Flatten[Solve[#==0,DeleteDuplicates[Cases[#,Subscript[a, _],Infinity]]]&[(#-(#//.Subscript[p, _]|Subscript[a, _]:>0))&[filteredList[Select[AllEliminate\[CapitalLambda]/.Subscript[l, i_]:>Subscript[l, i]+Subscript[a, i],!FreeQ[#,Subscript[l, _]]&]]//.Rule[a_,b_]:>b]]],
#]&[Flatten[Solve[#==0,DeleteDuplicates[Cases[#,Subscript[a, _],Infinity]]]&[foo2]]];
lShift=Table[Subscript[l, ii]->Subscript[l, ii]+Subscript[a, ii],{ii,noLoops}]//.aShift//.Subscript[a, _]:>0;
Return[{aShift,lShift}];
]


(* This is the main loop that generates from the graph and a list of edgFunction for LBL baikov (uncut) *)
LBL[edges_List,nodes_List,loopEdges_,verboseTrueOrFalse_: False]:=Module[{},
(*generate temp kinematics:*)
Substitutions=GenerateKinematics[Length[nodes]];
(*graph numbers:*)
If[SameQ[verboseTrueOrFalse,True],Echo[#," vertices = "],Nothing]&[vertices=Join[edges[[All,1]],nodes[[All,1]]]//Flatten//DeleteDuplicates//Sort];
If[SameQ[verboseTrueOrFalse,True],Echo[#,"noEdges ="],Nothing]&[noEdges=Length[edges]];
If[SameQ[verboseTrueOrFalse,True],Echo[#,"noVertices ="],Nothing]&[noVertices=Length[vertices]];
If[SameQ[verboseTrueOrFalse,True],Echo[#,"noLoops ="],Nothing]&[noLoops=1+noEdges-noVertices];
(* Assign momenta to the edges; q's will be solved for *)
edgesMomenta=Table[Subscript[q, e],{e,noEdges}];
Do[Echo[edgesMomenta[[loopEdges[[a]]]]=Subscript[l, a],"debug"],{a,Length[loopEdges]}];
(* Write down momentum conservation at every vertex *)
vertexMomenta=Table[0,{v,(*noEdges*)Max[Join[ Select[Flatten[edges],NumericQ],{noEdges}]]}];(*<-This is a safe patch because for any connected Feynman graph with at least one loop, the number of internal edges is always at least as large as the number of vertices by Euler's relation.*)
(*Here we assume that vertices are ordered 1,2,...,noVertices. Anything to improve here? Use SortBy?*)
Echo[edges,"edges"];
Echo[edgesMomenta,"edgesMomenta"];
Echo[vertexMomenta,"vertexMomenta"];
(* Loop over edges to update vertexMomenta *)
Do[
Echo[e=edges[[i,1]],"debug"];
vertexMomenta[[e[[1]]]]-=edgesMomenta[[i]];
vertexMomenta[[e[[2]]]]+=edgesMomenta[[i]];
,{i,noEdges}];
(*Adapt the nodes notation in terms of M, instead of p:*)
nodeMomenta=(#(*Assuming that that last momenta is linear dependent:*)/.#[[-1]]:>(Plus@@(-#[[1;;-2]])))&[Table[Subscript[p, ii],{ii,Length[nodes]}]];
nodes2=Table[{nodes[[ii]][[1]],nodeMomenta[[ii]]},{ii,Length[nodes]}];
Do[
vertexMomenta[[v[[1]]]]+=v[[2]];
,{v,nodes2}];
(*Rule that takes masses from substitution to values input in nodes[[i,2]]:*)
If[Length[Substitutions]>1,
substitutions=Substitutions/.(Thread[SortBy[DeleteDuplicates[Cases[Substitutions,Subscript[M, _],Infinity]],-LeafCount[#]&]->#]&[Table[nodes[[ii,2]],{ii,Length[nodes]}]]),
substitutions=Substitutions
];
MySubstitutions=substitutions;
(* Solve for momentum conservation:*)
If[SameQ[verboseTrueOrFalse,True],Echo[#,"edgesMomenta = "],Nothing]&[edgesMomenta=(If[#1=={},FLAG,edgesMomenta/.(#1[[1]])]&[Solve[vertexMomenta==0,Cases[Variables[edgesMomenta],Subscript[q, _]]]])];
If[SameQ[edgesMomenta,FLAG],
Print["Cannot solve for momentum conservation! Are you sure your choice of loop momenta labelling is correct?",$Failed];Abort[],
(* Write on-shell conditions:*)
If[SameQ[verboseTrueOrFalse,True],Echo[#,"onShellConditions = "],Nothing]&[onShellConditions=Table[edgesMomenta[[i]]\[CenterDot]edgesMomenta[[i]]-edges[[i,2]],{i,noEdges}]//.substitutions];
(* Kinematic invariants: *)
If[SameQ[verboseTrueOrFalse,True],Echo[#,"allInvariants = "],Nothing]&[allInvariants=Variables[onShellConditions]];
If[SameQ[verboseTrueOrFalse,True],Echo[#,"loopInvariants = "],Nothing]&[loopInvariants=Cases[allInvariants,Subscript[l, _]\[CenterDot]_]];
(*seeds for the loop:*)
extraPropagators={};
eliminate\[CapitalLambda][0]={};
(* The main loop over the independent loop momenta: *)
LE=Table[
If[SameQ[verboseTrueOrFalse,True],Echo["------- Looking at loop "<>ToString[a]<>"...-------"],Nothing];
loopMomenta=Select[Join[edgesMomenta,extraPropagators]//.Flatten[Table[eliminate\[CapitalLambda][A],{A,0,a-1}]],!FreeQ[#,Subscript[l, a]]&];
loopMomenta=Select[loopMomenta,Intersection[Variables[#],Table[Subscript[l, b],{b,a-1}]]==={}&];(* keep only those not used before *)
If[SameQ[verboseTrueOrFalse,True],Echo[#,ToString[a]<>") loopMomenta = "],Nothing]&[loopMomenta=DeleteDuplicates[(#/D[#,Subscript[l, a]])&/@loopMomenta]];(* bring into the form Subscript[l, a] + ... *)
(*Added to reduce superfluous scalar products:*)
loopMOMENTA[a]=loopMomenta;
ansatz[a]=Table[Subscript[l, a]+\[CapitalLambda][a][ii],{ii,Length[loopMOMENTA[a]]}];
eliminate\[CapitalLambda]TEMP[a]=Thread[Array[\[CapitalLambda][a],Length[#1]]->#1]&[loopMOMENTA[a]/.Subscript[l, a]:>0];
trivialRule=DeleteCases[eliminate\[CapitalLambda]TEMP[a]/.Rule[a_,b_]/;b=!=0:>dummy,dummy];
If[SameQ[verboseTrueOrFalse,True],Echo[#,"Lambda map = "],Nothing]&[eliminate\[CapitalLambda][a]=DeleteCases[eliminate\[CapitalLambda]TEMP[a],Alternatives@@trivialRule]];
If[SameQ[verboseTrueOrFalse,True],Echo[#,"Loop momenta = "],Nothing]&[loopMomenta=ansatz[a]/.trivialRule];
(* Construct the revelant Gram matrix *)
Gram=Expand[Table[Subscript[v, 1]\[CenterDot]Subscript[v, 2],{Subscript[v, 1],loopMomenta},{Subscript[v, 2],loopMomenta}]]//.substitutions;
gramLoop[a]=Gram;
extraPropagators=Join[extraPropagators,Flatten[Table[loopMomenta[[j]]-loopMomenta[[i]],{i,Length[loopMomenta]},{j,i+1,Length[loopMomenta]}]]];
(* Compute the external Gram determinant *)
externalGram=Table[(Subscript[v, 1]-Subscript[l, a])\[CenterDot](Subscript[v, 2]-Subscript[l, a]),{Subscript[v, 1],Complement[loopMomenta,{Subscript[l, a]}]},{Subscript[v, 2],Complement[loopMomenta,{Subscript[l, a]}]}]//Expand[#]//.substitutions&;
gramExt[a]=externalGram;
If[SameQ[verboseTrueOrFalse,True],Echo["------- Done with loop "<>ToString[a]<>"!-------"],Nothing];
MatrixForm/@{gramExt[a],gramLoop[a]}
,{a,noLoops}];
Echo[Style["------- Done with all loops! Summary: -------",Blue]];
(*kinematic used:*)
Echo[substitutions,"Kinematic substitutions ="];
(*record some variables:*)
If[SameQ[verboseTrueOrFalse,True],Echo[#,"Eliminate \[CapitalLambda] ="],Nothing]&[AllEliminate\[CapitalLambda]=Flatten[Table[eliminate\[CapitalLambda][A],{A,noLoops}]]];
If[SameQ[verboseTrueOrFalse,True],Echo[#,"Is there any relations between the \[CapitalLambda]s found above? ="],Nothing]&[relLamdas=If[SameQ[#,{DUMMY,dummy}],NONE,DeleteCases[#,dummy->DUMMY]]&[
(List@@LogicalExpand[(Eliminate[(#//.Rule[a_,b_]:>a-b)==0,DeleteDuplicates[Cases[#,Subscript[_,_],Infinity]]]&&dummy==DUMMY)&[AllEliminate\[CapitalLambda]]])/. (lhs_==rhs_):>Thread[(#1[[1]]->#1[[-1]])&[SortBy[{lhs,rhs},Length]]]//.Rule[-A1_,A2_]:>Rule[A1,-A2]
]];
If[SameQ[verboseTrueOrFalse,True],Echo[#," Momenta in terms of Lambda variables = "],Nothing]&[psAs\[CapitalLambda]=Flatten[Solve[(#//.Rule[a_,b_]:>a-b)==0,DeleteDuplicates[Cases[#,Subscript[_,_],Infinity]]]&[AllEliminate\[CapitalLambda]//.If[SameQ[relLamdas,NONE],{},relLamdas]]]];
If[SameQ[verboseTrueOrFalse,True],Echo[#,"\[CapitalLambda]s depending on ls = "],Nothing]&[loopBack=If[SameQ[#,{}],NONE,#]&[
Quiet[Flatten[Solve[(#//.Rule[a_,b_]:>a-b)==0,Select[DeleteDuplicates[Cases[#,\[CapitalLambda][_][_],Infinity]],!FreeQ[#//.AllEliminate\[CapitalLambda],Subscript[l, __]]&]]&[Select[psAs\[CapitalLambda],!FreeQ[#,Subscript[l, _]]&]]]&[Select[psAs\[CapitalLambda],!FreeQ[#,Subscript[l, _]]&]]]
]];
(* expected (minimal) number of integration variables: *)
If[SameQ[verboseTrueOrFalse,True],Echo[#,"Number of expected scalar products (integration variables) = "],Nothing]&[nLBL=noLoops+Length[AllEliminate\[CapitalLambda]]];
(*Function to detect if loop momentum shifts are needed:*)
If[SameQ[verboseTrueOrFalse,True],Echo[#,"Shift in loop momenta = "],Nothing]&[shift=If[Length[DeleteDuplicates[Cases[Flatten[LE//.AllEliminate\[CapitalLambda],1],Subscript[l, _]\[CenterDot]_,Infinity]]]-nLBL>0,
If[SameQ[verboseTrueOrFalse,True],Echo[#,"Looking for loop momenta shift..."],#]&[FindLoopMomShift[AllEliminate\[CapitalLambda]][[-1]]],
If[SameQ[verboseTrueOrFalse,True],Echo[#,"Number of integration variables already minimized! Proceeding..."],#]&[{}]
]];
(*final on-shell conditions solved:*)
onShellConditions2=onShellConditions/.shift//.substitutions//Simplify;
MyPropagators=onShellConditions2;
temp[0]=onShellConditions2;
sol[0]={};
Do[
sol[a]=Flatten[Quiet@Solve[#==0,DeleteDuplicates[Cases[#,Subscript[l, a]\[CenterDot]_,Infinity]]]&[Select[onShellConditions2//.Flatten[Table[sol[b-1],{b,a}]],!FreeQ[#,Subscript[l, a]]&]]]
,{a,noLoops}];
SolvedOnShellCond=Flatten[Simplify[Table[sol[a],{a,noLoops}]]];
(*return loop output:*)
out000=Simplify[Flatten[Expand[Expand[Expand[Expand[LE]//.AllEliminate\[CapitalLambda]]/.shift]//.substitutions],1]];
(*looking for rank drop:*)
out=rankDropRule[out000];
(*check the number of variables is minimized:*)
If[SameQ[Length[DeleteDuplicates[Cases[out,Subscript[l, _]\[CenterDot]_,Infinity]]],nLBL],
Echo[Style["The number of integration variables ("<>ToString[nLBL]<>") is matching expected bound!",Blue]],
If[
Echo[Style["It seems like the number of integration variables ("<>ToString[Length[DeleteDuplicates[Cases[out,Subscript[l, _]\[CenterDot]_,Infinity]]]]<>") is below expected bound!",Green]],
Echo[Style["It seems like the number of integration variables ("<>ToString[Length[DeleteDuplicates[Cases[out,Subscript[l, _]\[CenterDot]_,Infinity]]]]<>") is above expected bound! You should probably reconsider the input of loop edges.",Red]]
]
];
(*final answer and things to print:*)
(*Feynman graph:*)
If[SameQ[verboseTrueOrFalse,True],Echo[#,"Edges momenta (after potential shift) = "],Nothing]&[finalEdgeMom=edgesMomenta/.shift];
(*Print[PlotDiagram[#[[1]]&/@edges,nodes2,finalEdgeMom,loopEdges]];*)
(*Echo[SolvedOnShellCond,"On shell conditions solved in the LBL order = "];*)
Return[out];
];
]


(*function to construct the LBL integrand in the propagator basis: *)
Options[SOFIABaikov]={MyEdgeLabels->Automatic,ShowXsDefinition->False};
SOFIABaikov[edgesnodes_,opts:OptionsPattern[](*loopEdges_,PrintXs_:False*)]:=SOFIABaikov[edgesnodes[[1]],edgesnodes[[-1]],opts(*loopEdges,PrintXs*)];
SOFIABaikov[edges_,nodes_,opts:OptionsPattern[](*loopEdges_,PrintXs_:False*)]:=
EchoTiming[QuietEcho[
Module[{momLabel,EdgeLabels,ShowXsDeFinition},
(*added:*)
{EdgeLabels,ShowXsDeFinition}=OptionValue[{MyEdgeLabels,ShowXsDefinition}];
momLabel=If[SameQ[EdgeLabels,Automatic],Echo[FixLoopEdges[Join[{edges},{nodes}]],"Choice of loop edges made by the code:"],EdgeLabels]//QuietEcho;
data=LBL[edges,nodes,momLabel(*loopEdges*)];
(* find the change of variables where the propagors + ISPs are integration variables: *)
sol1=Flatten[Simplify[Solve[#1==0,SolvedOnShellCond//.Rule[a_,b_]:>a]]]&[(#-Array[x,Length[#1]]&[onShellConditions2])];
ISP1=Thread[#1->x/@Range[Length[SolvedOnShellCond]+1,Length[SolvedOnShellCond]+Length[#1]]]&[DeleteDuplicates[Cases[sol1/.Rule[a_,b_]:>b,_\[CenterDot]_,Infinity]]];
sol2=Join[sol1//.ISP1,ISP1];
ISP2=Thread[#1->x/@Range[Length[sol2]+1,Length[sol2]+Length[#1]]]&[DeleteDuplicates[Cases[data//.sol2//Factor,_\[CenterDot]_,Infinity]]];
Echo[solFinal=Join[sol2,ISP2]//.x[i_]:>ToExpression["x"<>ToString[i]],"Change of variables to propagator basis = "];
Echo[takeMaxCut=Thread[Array[x,Length[#1]]->ConstantArray[0,Length[#1]]]&[onShellConditions2]//.x[i_]:>ToExpression["x"<>ToString[i]],"Maximal cut conditions = "];
Echo[matrices=Simplify[(out//.solFinal)],"Uncut external (odd positions) and internal (even positions) Gram matrices = "];
(*Print[TableForm[matrices],"Uncut external (odd positions) and internal (even positions) Gram matrices = "];*)
(*List of E's:*)
Elist=Length[#[[1]]]&/@(#1[[Select[Range[Length[#1]],OddQ[#]&]]]&[matrices]);
(*List the x's:*)
xs=SortBy[DeleteDuplicates[Cases[matrices,x_Symbol/;StringMatchQ[SymbolName[x],"x"~~DigitCharacter..],{0,Infinity}]],StringLength@ToString[#]&];
xs000=SortBy[DeleteDuplicates[Cases[solFinal//.Rule[a_,b_]:>a-b,x_Symbol/;StringMatchQ[SymbolName[x],"x"~~DigitCharacter..],{0,Infinity}]],StringLength@ToString[#]&];
xsExpanded=Flatten[solFinal//.Rule[a_,b_]:>a-b//Solve[#==0,xs000]&];
If[SameQ[ShowXsDeFinition,False],Nothing,Print["x's in terms of dot products:",xsExpanded]];
(*Integrand*)
integrand=((-2^(noLoops-Length[xs]) (-I)^noLoops Pi^((noLoops-Length[xs])/2))/Product[Gamma[(dim-Elist[[ii]])/2],{ii,Length[Elist]}])(((Wedge@@Map[d[#]&,#1//.\[Nu][__]:>1])(Times@@If[Length[onShellConditions2]==Length[#1],1,#[[Length[onShellConditions2]+1;;-1]]]/Times@@(#[[;;Length[onShellConditions2]]])))&[#^\[Nu]/@Range[Length[#]]&[xs]])(Times@@(Table[Det[#1[[ii]][[1]][[1]]]^((Elist[[ii]]-dim+1)/2) Det[#1[[ii]][[-1]][[1]]]^((dim-Elist[[ii]]-2)/2),{ii,Length[#1]}]&[Partition[matrices,2]]));
Return[Echo[integrand,"Uncut LBL Baikov = "]];
]],"Total time = "]


(* Function to take the maximal cut 
[Note: applying the on-shell conditions can make one or more Gram determinant zero -- e.g., happens when the diagram is always UV/IR divergent) 
*)
Clear[TakeMaxCut]
TakeMaxCut[lblIntegrand_,dimRule_:{}]:=QuietEcho[Module[{},
Clear[propsX,\[Nu]Map,maxcut];
propsX=xs[[;;Length[onShellConditions2]]];
\[Nu]Map=Thread[#->ConstantArray[1,Length[#1]]]&[\[Nu]/@Range[Length[onShellConditions2]]];
maxcut=((Times@@propsX)(integrand/.\[Nu]Map/.Join[{\[Nu][i_]:>0},dimRule]))//.takeMaxCut//.Wedge@@{a___,d[0],b___}:>Wedge@@{a,b}//.Wedge[]:>1//.Wedge[d[a_]]:>d[a];
Return[Echo[maxcut,"Maximal cut LBL Baikov = "]];
]]


NumberOfCriticalPoints[integrand_,vars_]:=Length[Solve[#==0,vars]&[DeleteCases[Cases[Collect[d[Log[TakeMaxCut[integrand]//.Wedge[___]:>1//.d[__]:>1]]//.Applyd[vars],d[__],Factor]+dummy,_],dummy]//.d[___]:>1//Factor//Numerator]]


(* ::Section::Closed:: *)
(*TrySolveStandardLandau*)


(*Function added to find edges contributing to each loop:*)
IdentifyTheLoops[edgesnodes_]:=QuietEcho[Module[{basis,edgesin,nodesin,pos,cycles,edges,nodes,edgelist,vertices,intmasses,extmasses,vmax,masslessedges,masslesspos,vmasslesspos,allEdges,multiplicity,graph0,edgelistgraph,graph,ContactQ,outt},
edgesin=edgesnodes[[1]];
nodesin=edgesnodes[[-1]];
ContactQ=SameQ[edgesin,{}];
If[ContactQ, {edges={},nodes=nodesin},
If[Length[Part[Flatten/@edgesin,1]]==3,{edges=edgesin,nodes=nodesin}, {nodes=edgesin,edges=nodesin}];];
edgelist=Sort/@(#[[1]]&/@edges);
vertices=If[ContactQ,{1},Sort[DeleteDuplicates[Flatten[edgelist]]]];
intmasses=PowerExpand[Sqrt[#[[2]]]]&/@edges;
extmasses=#[[2]]&/@nodes;
vmax=vertices[[-1]];
masslesspos=Position[Join[intmasses,extmasses],0]//Flatten;
vmasslesspos=(Position[extmasses,0]//Flatten)+vmax;
allEdges=#[[1]]\[UndirectedEdge]#[[2]]&/@Join[edgelist,Table[{nodes[[v,1]],vmax+v},{v,Length[nodes]}]];
multiplicity=Sort[Transpose[Tally[allEdges]][[2]]][[-1]];
graph0=EdgeTaggedGraph[Join[vertices,Range[vmax+1,vmax+Length[nodes]]],allEdges];
edgelistgraph=EdgeList[graph0]//Echo;
basis=FindFundamentalCycles[edgelistgraph];
(*Build all simple cycles*)
cycles=
(normalizeEdge/@#&)/@(SortBy[addedges[Pick[basis,#,1]]&/@Most[Tuples[{1,0},Length[basis]]],Length][[1;;NLoops[edgesnodes]]]);
outt=Map[SortBy[Flatten[#],Length]&,Table[Position[edgelistgraph,#1[[ii]][[jj]]],{ii,Length[#1]},{jj,Length[#1[[ii]]]}]&[cycles]];
Return[outt];
]]

(*Locality conditions:*)
LocalityConditions[edgesnodes_]:=Module[{VectorConditions,sols},
VectorConditions=Simplify[Table[Array[\[Alpha][ii],Length[#[[ii]]]] . #[[ii]],{ii,Length[#1]}]&[finalEdgeMom[[#]]&/@IdentifyTheLoops[edgesnodes]]];
sols=Flatten[Solve[#==0,DeleteDuplicates[Cases[#,Subscript[l, ___],Infinity]]]&[VectorConditions]];
Return[sols];
]


TrySolveStandardLandau[diag_,KinematicVariablesToEliminate_]:=Module[{lc,sol1,sol2},
SOFIABaikov[diag,ShowXsDefinition->False];
lc=LocalityConditions[diag];
Print["Locality condition(s):",lc];
sol1=MyPropagators//.Rule[a_,b_]:>b//.lc//.(a__ b_)\[CenterDot](c_)/;FreeQ[a,p]:>a(b\[CenterDot]c)//.MySubstitutions//Solve[#==0,Join[DeleteDuplicates[Cases[lc,\[Alpha][__][__],Infinity]],KinematicVariablesToEliminate]]&//Quiet;
sol2=lc//.sol1//Simplify;
Return[{sol1,sol2}]
]


(* ::Section::Closed:: *)
(*Prepare the singularity system*)


prepareLandauSystem[Edges_,Nodes_,MomLabel_,optionMaxCut_,optionJulia_]:=Module[{inutile1,inutile2,inutile3,Glist,GlistOS,listOfDet},
inutile1=QuietEcho[SOFIABaikov[Edges,Nodes,MyEdgeLabels->MomLabel,ShowXsDefinition->False(*MomLabel,False*)]];
inutile2=QuietEcho[TakeMaxCut[integrand]];
Glist=matrices;
GlistOS=MatrixForm[#[[1]]]&/@(Glist//. If[SameQ[optionMaxCut,True],takeMaxCut,{}]);
gramList=homogeneizeKin[Det[#[[1]]]&/@GlistOS];
active=DeleteDuplicates[Cases[gramList,x_Symbol/;StringMatchQ[SymbolName[x],"x"~~DigitCharacter..],{0,Infinity}]];
inutile3=If[SameQ[optionJulia,True],QuietEcho[sendSystemToJulia[gramList]],{}];
Return[gramList];
]


(* ::Section::Closed:: *)
(*SOFIASingularities*)


(*This command can be used to setup the Landau analysis with many options:*)
Options[SOFIASingularitiesSEED]={IncludeISPs->False,NumericalSubstitutions->{},MyEdgeLabels->Automatic,WorkOnMaxCut->True,WhichSolver->FastFubini,LaunchJulia->False,PolynomialSizeLimit->100,FiniteFieldsModulus->0,FactorSolverResult->True,PLDMethod->sym,PLDHomogeneous->true,PLDHighPrecision->false,PLDCodimStart->-1,PLDFaceStart->1,PLDRunASingleFace->false};
SOFIASingularitiesSEED[edgenode_,opts:OptionsPattern[]]:=Module[{ISPSIN,nUmerics,momLabel,landau0,EdgeLabels,sOlver,MaximalCut,RunJulia,lImit,mOdulus,fActorLast,PLDmethOd,PLDhOm,PLDhP,PLDcodimStaRt,PLDfaceStaRt,PLDsingleFaCe},
{ISPSIN,nUmerics,EdgeLabels,sOlver,MaximalCut,RunJulia,lImit,mOdulus,fActorLast,PLDmethOd,PLDhOm,PLDhP,PLDcodimStaRt,PLDfaceStaRt,PLDsingleFaCe}=OptionValue[{IncludeISPs,NumericalSubstitutions,MyEdgeLabels,WhichSolver,WorkOnMaxCut,LaunchJulia,PolynomialSizeLimit,FiniteFieldsModulus,FactorSolverResult,PLDMethod,PLDHomogeneous,PLDHighPrecision,PLDCodimStart,PLDFaceStart,PLDRunASingleFace}];
(*Make a choice of edge labels:*)
momLabel=If[SameQ[EdgeLabels,Automatic],Echo[FixLoopEdges[edgenode],"Choice of loop edges made by the code:"],EdgeLabels]//QuietEcho;
(*Prepare the system of equations needed to find Landau singularities:*)
prepareLandauSystem[edgenode[[1]],edgenode[[-1]],momLabel,MaximalCut,RunJulia];
(*Solve the system of equations:*)
Echo[TableForm[Factor[gramList]],"List of the Gram determinants:"];
Echo[active,"Variables to eliminate:"];
landau0=
If[SameQ[sOlver,momentumPLD],
momentumPLD[Join[(*(*added: jan 28 2025*)active*){},SortBy[gramList,Length]],PLDmethOd,PLDhOm,PLDhP,PLDcodimStaRt,PLDfaceStaRt,PLDsingleFaCe],
SortBy[sOlver[
If[SameQ[MaximalCut,True],
Join[If[SameQ[ISPSIN,False],{},active],SortBy[gramList,Length]],
Join[If[SameQ[ISPSIN,False],takeMaxCut[[All,1]],active],SortBy[gramList,Length]]
]//.nUmerics
,
active
(*RandomSample[active]*)
,lImit,mOdulus,fActorLast],LeafCount[#]&]
];
Return[landau0];
]
(*A final command that puts everything together:*)
Options[SOFIASingularities]={
IncludeSubtopologies->False,StartAtSubtopology->1,EndAtSubtopology->-1,DebugOptionUnclog->False,DebugOptionUnclogTime->5*60,
IncludeISPs->False,NumericalSubstitutions->{},MyEdgeLabels->Automatic,WorkOnMaxCut->True,WhichSolver->FastFubini,LaunchJulia->False,PolynomialSizeLimit->100,FiniteFieldsModulus->0,FactorSolverResult->True,PLDMethod->sym,PLDHomogeneous->true,PLDHighPrecision->false,PLDCodimStart->-1,PLDFaceStart->1,PLDRunASingleFace->false
};
SOFIASingularities[edgenode_,opts:OptionsPattern[]]:=EchoTiming[Quiet[QuietEcho[Module[
{RunContrActed,contractionS,resultFromSeed,StartAtSubtopOlogy,EndAtSubtopOlogy,deCloG,DebugOptionUnclogTimE},
{RunContrActed,StartAtSubtopOlogy,EndAtSubtopOlogy,deCloG,DebugOptionUnclogTimE}=OptionValue[{IncludeSubtopologies,StartAtSubtopology,EndAtSubtopology,DebugOptionUnclog,DebugOptionUnclogTime}];
contractionS=If[SameQ[RunContrActed,False],
Nothing,
DeleteDuplicates[{{SortBy[#[[1]],Length],#[[-1]]}&/@(#[[1]]),#[[-1]]}&/@(ContractionsNontrivial[edgenode][[StartAtSubtopOlogy;;EndAtSubtopOlogy]])]
];
resultFromSeed=
If[Position[{opts},momentumPLD]=={},
SortBy[#1,LeafCount[#1]&],#1]&[
If[SameQ[RunContrActed,False],
SOFIASingularitiesSEED[edgenode,FilterRules[{opts},Options[SOFIASingularitiesSEED]]],
timed[
DynamicModule[
  {i = 0, skippedIndices = {}, maxTime = DebugOptionUnclogTimE, declog = deCloG},
  res = Monitor[
    Table[
      i++;
      With[{
        result = 
        If[
          SameQ[declog, True],
          TimeConstrained[
            SOFIASingularitiesSEED[
              contractionS[[j]], 
              FilterRules[{opts}, Options[SOFIASingularitiesSEED]]
            ], 
            maxTime, 
            Nothing
          ],
          SOFIASingularitiesSEED[
            contractionS[[j]], 
            FilterRules[{opts}, Options[SOFIASingularitiesSEED]]
          ]
        ]
      },
      If[
        SameQ[result, Nothing] && SameQ[declog, True],
        AppendTo[skippedIndices, j];
        Nothing,
        Echo[result, FeynmanPlot[contractionS[[j]]]]
      ]
    ],
    {j, Length[contractionS]}
    ],
    Column[{
      ProgressIndicator[Dynamic[i], {0, Length[contractionS]}],
      Dynamic[Row[{"Subtopology ", i, " of ", Length[contractionS]}]],
      If[
        SameQ[declog, True], 
        Dynamic[Style["Unclogging: Skipped over subtopologies " <> ToString[skippedIndices], Red]], 
        Nothing
      ]
    }]
  ];
  Print["Final Skipped Indices: ", skippedIndices];
];
];
DeleteCases[Select[DeleteDuplicates[Flatten[FactorList[#][[All,1]]&/@Flatten[res]]],!NumericQ[#]&],Alternatives@@{Det[___],{}[[-1]]}(*<-- to fix?*)]
]];
Return[resultFromSeed];
]]]]


(* ::Section::Closed:: *)
(*Effortless related functions*)


(*TODO: make "ConstantCoefficientList" a tunable option in FindLetters and SOFIA.*)


FindLetters[landaulist_(*,extra_:{}*)]:=Module[{vars},
canlist=Select[DeleteDuplicates[Flatten[FactorList[#][[All,1]]&/@landaulist]],!NumericQ[#]&]; (* puts Landau singularities into effortless form *);
vars=Variables[canlist];
evenAlpha=Table[w[i]->Log[canlist[[i]]],{i,canlist//Length}];
SqrtRepl=Table[r[i]->Sqrt[canlist[[i]]],{i,canlist//Length}];(*Q: Better logic to distinguish which potential singularities are roots?*)
outEF=DeleteCases[
RunEffortlessIndependentFF[Table[r[i],{i,canlist//Length}],
evenAlpha,
SqrtRepl,
vars,
"Verbose"->False,
"DoubleSquareRoots"->True,
"ConstantCoefficientList" -> Join[{(*1, 2, 3, 4, 8, 1/2, 1/4, 1/3*)1,2,4},-{(*4*)(*1, 2, 3, 4, 8, 1/2, 1/4, 1/3*)}](*Q: How do we know what to put here? Deterministic?*)
(*,"ExtraPolynomials" -> extra*)
]
,Alternatives@@{I Pi}];
Return[outEF];
]


(*(A+Sqrt[_]Sqrt[_] )/(A-Sqrt[_]Sqrt[_])*)


Options[SOFIA]={
AddSing->{},ChangeMyVariables->{},
IncludeSubtopologies->False,StartAtSubtopology->1,EndAtSubtopology->-1,DebugOptionUnclog->False,DebugOptionUnclogTime->5*60,
IncludeISPs->False,NumericalSubstitutions->{},MyEdgeLabels->Automatic,WorkOnMaxCut->True,WhichSolver->FastFubini,LaunchJulia->False,PolynomialSizeLimit->100,FiniteFieldsModulus->0,FactorSolverResult->True,PLDMethod->sym,PLDHomogeneous->true,PLDHighPrecision->false,PLDCodimStart->-1,PLDFaceStart->1,PLDRunASingleFace->false
};
SOFIA[edgenode_,opts:OptionsPattern[]]:=QuietEcho[Module[{sing,AddSIng,runEL,ChangeMyVariAbles},
{AddSIng,ChangeMyVariAbles}=OptionValue[{AddSing,ChangeMyVariables}];
Echo[sing=
Quiet[If[SameQ[ChangeMyVariAbles,{}],#1,MyFactorList[#1//.ChangeMyVariAbles]]]&[EchoTiming[QuietEcho[Join[SOFIASingularities[edgenode,FilterRules[{opts},Options[SOFIASingularities]]],AddSIng]]],"Candidate singularities found:"]];
Print["Candidate singularities found:",sing];
runEL=Quiet[FindLetters[sing]];
Print["List of square roots and rational entries:",Join[SqrtRepl,evenAlpha]];
Print["List of logarithmic letters:",outEF];
Return[{{runEL},{Join[SqrtRepl,evenAlpha]}}];
]]


(* ::Section:: *)
(*JULIA*)


PrintTemporary["-------> [Loading external dependencies ...] <-------"];
js=StartExternalSession["Julia"]
ExternalEvaluate[js,"using Pkg"]
PrintTemporary["-------> [Looking for: Oscar, HomotopyContinuation and GAP ...] <-------"];
ExternalEvaluate[js,"Pkg.add(\"Oscar\")"]
ExternalEvaluate[js,"Pkg.add(\"HomotopyContinuation\")"]
ExternalEvaluate[js,"Pkg.add(\"GAP\")"]
PrintTemporary["-------> [Activating PLD ...] <-------"];
ExternalEvaluate[js,"Pkg.activate(\"/Users/feynman_voyager_2/Desktop/Landau/PLD/Project.toml\")"]
PrintTemporary["-------> [Loading PLD ...] <-------"];
ExternalEvaluate[js,"using PLD"]
ExternalEvaluate[js,"using GAP"]
ExternalEvaluate[js,"using Oscar"]
ExternalEvaluate[js,"using HomotopyContinuation"]
PrintTemporary["-------> [Checking status...] <-------"];
ExternalEvaluate[js,"Pkg.status()"]


(*--------Numerical solvers--------*)
(*Preparing conversion: polynomials in the input can depend on either {Subscript[l, _]\[CenterDot]_} OR {x1,...} as active variables.*)
prepareVariables[listOfGram_]:=Module[{},
Clear[toX,gramList,active,kinematics];
Echo[toX=Thread[#1->(ToExpression["x"<>ToString[#]]&/@Range[Length[#1]])]&[DeleteDuplicates[Cases[listOfGram,Alternatives@@{Subscript[l, _]\[CenterDot]_,_\[CenterDot]Subscript[l, _]},Infinity]]],"toX ="];
Echo[gramList=Factor[listOfGram//.toX],"gramDetList ="];
Echo[active=If[!SameQ[toX,{}],(toX/.Rule[a_,b_]:>b),DeleteDuplicates[Cases[listOfGram,x_Symbol/;StringMatchQ[SymbolName[x],"x"~~DigitCharacter..],{0,Infinity}]]],"active (loop) variables ="];
Echo[kinematics=DeleteCases[Variables[gramList],Alternatives@@active],"kinematics = "];
(*Echo[*)alphas=(ToExpression["\[Alpha]"<>ToString[#]]&/@Range[0,Length[#1]-1])&[listOfGram](*,"alphas = "]*);
(*Echo[*)Gs=(ToExpression["G"<>ToString[#]]&/@Range[0,Length[#1]-1])&[listOfGram](*,"G's = "]*);
Echo[allActive=Join[active,alphas],"allActive = "];
]
(* define ring of coefficients: *)
Clear[defineCoefRing]
defineCoefRing[kin_]:=Module[{},
varNames=SymbolName/@kin;
varTupleString="("<>StringRiffle[varNames,", "]<>")";
varListString="[\""<>StringRiffle[varNames,"\", \""]<>"\"]";
codeString="R, "<>varTupleString<>" = PolynomialRing(QQ, "<>varListString<>"); println(R); \"Ring defined\"";
result=ExternalEvaluate[js,codeString]
]
(* define Laurent polynomial ring (ring of active variables): *)
Clear[defineLaurentRing]
defineLaurentRing[allActive_]:=Module[{},
varNames2=SymbolName/@allActive;
varTupleString2="("<>StringRiffle[varNames2,", "]<>")";
varListString2="[\""<>StringRiffle[varNames2,"\", \""]<>"\"]";
codeString2="S, "<>varTupleString2<>" = LaurentPolynomialRing(R, "<>varListString2<>"); println(S); \"Laurent ring defined\"";
result2=ExternalEvaluate[js,codeString2]
]
(* processing polynomials to julia form: *)
toJuliaString[expr_]:=StringReplace[ToString[InputForm[expr]],{"Power["->"(",","->")^"," "->"","Plus["->"(","Times["->"(","]"->")","Sqrt["->"sqrt(","^"->"^"}];
giList[polynomials_]:=ExternalEvaluate[js,StringReplace[#,"/"->"//"]]&/@MapIndexed[Module[{giIndex,giName,polyString},giIndex=First[#2]-1;
giName="G"<>ToString[giIndex];
polyString=toJuliaString[#1];
codeString3=giName<>" = "<>polyString<>"; string("<>giName<>")";
codeString3]&,Numerator[Factor[polynomials]]];
(* call momentum space PLD: *)
ComputeDiscriminants[js_, methodNumOrSym_ : sym, homogeneousTrueOrFalse_ : false, highPrecTrueOrFalse_ : false, codimStart_ : -1, faceStart_ : 1, singleFace_ : false]:=Block[{codeString,result},
  codeString = "
    discriminants = getSpecializedPAD(Delta, gens(R), gens(S); high_prec="<>ToString[highPrecTrueOrFalse]<>", method=:"<>ToString[methodNumOrSym]<>", homogeneous="<>ToString[homogeneousTrueOrFalse]<>", codim_start="<>ToString[codimStart]<>", face_start="<>ToString[faceStart]<>", single_face="<>ToString[singleFace]<>");
    string(discriminants);
    \"Discriminants computed!\"
  ";
 (* remove leading/trailing whitespaces: *)
  codeString = StringTrim[codeString];
  result = ExternalEvaluate[js, codeString];
   Return[result];
]
(* generate system in Julia: *)
sendSystemToJulia[polynomials_]:=Module[{out},
temp1=prepareVariables[polynomials];
temp2=defineCoefRing[kinematics];
temp3=defineLaurentRing[allActive];
temp4=giList[gramList];
DELTA=Echo[ExternalEvaluate[js,"Delta = "<>StringReplace[ToString[InputForm[(alphas/.Thread[ToExpression["\[Alpha]"<>ToString[Length[gramList]-1]]->1](*//.\[Alpha]0->1*)) . Gs]],"\\[Alpha]"->"\[Alpha]"]<>"; string(Delta)"],"\[CapitalDelta] = "];
]
(* define and compute the principle (Landau) A discriminant: *)
momentumPLD[polynomials_, methodNumOrSym_ : sym, homogeneousTrueOrFalse_ : false, highPrecTrueOrFalse_ : false, codimStart_ : -1, faceStart_ : 1, singleFace_ : false]:=Module[{out},
temp1=prepareVariables[polynomials];
temp2=defineCoefRing[kinematics];
temp3=defineLaurentRing[allActive];
temp4=giList[gramList];
Echo[ExternalEvaluate[js,"Delta = "<>StringReplace[ToString[InputForm[(alphas/.Thread[ToExpression["\[Alpha]"<>ToString[Length[gramList]-1]]->1](*//.\[Alpha]0->1*)) . Gs]],"\\[Alpha]"->"\[Alpha]"]<>"; string(Delta)"],"\[CapitalDelta] = "];
out=ComputeDiscriminants[js, methodNumOrSym, homogeneousTrueOrFalse, highPrecTrueOrFalse, codimStart, faceStart, singleFace];
Return[out];
]
(* define Laurent polynomial ring (ring of active variables): *)
Clear[defineLaurentRingEuler]
defineLaurentRingEuler[allActive_]:=Module[{},
varNames2Euler=SymbolName/@DeleteCases[allActive,\[Alpha]0];
varTupleString2Euler="("<>StringRiffle[varNames2Euler,", "]<>")";
varListString2Euler="[\""<>StringRiffle[varNames2Euler,"\", \""]<>"\"]";
codeString2Euler="SHOM, "<>varTupleString2Euler<>" = LaurentPolynomialRing(R, "<>varListString2Euler<>"); println(SHOM); \"Homogeneized Laurent ring defined\"";
result2Euler=ExternalEvaluate[js,codeString2Euler]
]
(* compares Euler characteristic near candidate singularities with generic Euler characteristic: *)
EulerDiscriminant[polynomials_,candidates0_,repeatsSteps_]:=Module[{out},
candidates=Select[candidates0,Length[#]>2&];(*TODO: seems that we need to drop Length[#]>2 for the algoritm not to complain...*)
QuietEcho[temp1=prepareVariables[polynomials]];
Echo["Homogeneized the system sending \[Alpha]0 -> 1!"];
temp2=defineCoefRing[kinematics];
temp3=defineLaurentRingEuler[allActive];
temp4=giList[gramList];
ExternalEvaluate[js,"DeltaHOM = "<>StringReplace[ToString[InputForm[(alphas//.\[Alpha]0->1) . Gs]],"\\[Alpha]"->"\[Alpha]"]<>"; string(DeltaHOM)"];
ExternalEvaluate[js, "can = "<>StringReplace[ToString[InputForm[candidates]], {"{" -> "[", "}" -> "]"}]<>"; string(can)"];
(*Echo[*)ExternalEvaluate[js,"ed = EulerDiscriminantQ(DeltaHOM, gens(R), gens(SHOM), can, repeats="<>ToString[repeatsSteps]<>"); string(ed)"](*,"Candidate singularities with Euler characteristic drop = "]*);
]


(* ::Section:: *)
(*End*)


(*Documentation:*)
FeynmanDraw::usage = "Running this function will trigger a drawing window for you to draw your diagram with your mouse."
FeynmanPlot::usage = "Draw the input diagram."
FastFubini::usage = "Eliminates given variables in a given set of polynomials. We make it available in case someone wants to solve a non-Feynman system."
BrownPanzer::usage = "Eliminates given variables in a given set of polynomials. We make it available in case someone wants to solve a non-Feynman system."
FixLoopEdges::usage = "Finds an 'optimal' label of the loops."
timed::usage = "Function for real-time timing."
homogeneizeKin::usage = "This function homogeneize kinematics."
Applyd::usage = "Expands the exterior derivative d[...] in specified variables."
GenerateKinematics::usage = "Generatate n-point kinematics."
ContractionsNontrivial::usage = "Generate non-trivial subtopologies."
LBL::usage = "This functions generates the Baikov matrices from diagram intput. It is the base function of SOFIABaikov."
SOFIABaikov::usage = "Returns the optimized LBL Baikov representation."
TakeMaxCut::usage = "Take the LBL Baikov integrand on the maximal cut."
SOFIASingularities::usage = "Returns a list of singularities for an input Feynman graph."
SOFIA::usage = "Returns the singularities or letters depending on options."
integrand::usage= "The loop-by-loop integrand output of SOFIABaikov."
NumberOfCriticalPoints::usage= "Counts the number of critical points/master integrals from the Baikov representation."
matrices::usage= "The Baikov matrices/Gram determinants: external (odd positions) and internal (even positions) Gram matrices."
gramList::usage= "List of the determinants of 'matrices'."
active::usage= "A list of active (integration) variables."
s::usage= "Label for Mandelstam variables."
dim::usage= "Space-time dimension."
m::usage= "Mass scale (usually internal)."
M::usage=  "Mass scale (usually external)."
d::usage= "Exterior derivative."
\[Nu]::usage= "An integer."
q::usage= "Dummy label for edges loop momenta."
mm::usage= "Mass scale squared (usually internal)."
MM::usage= "Mass scale squared (usually external)."
t::usage= "Label for Mandelstam variables."
l::usage= "Label for loop momenta."
p::usage= "Label for external momenta."
wedge1::usage= "First rule to deal with wedge products."
wedge2::usage= "Second rule to deal with wedge products."
MyFactorList::usage= "Factors a list of polynomials in a list of irreducile components."
finalEdgeMom::usage= "List of edges momenta choosen by SOFIABaikov. It should be such that the number of integration variables is minimized."
IdentifyTheLoops::usage= "Finds edges contributing to each loop (taken as simple cycles)."
LocalityConditions::usage= "For a given diagram, this will return the loop momenta in terms of standard Schwinger parameters \[Alpha]."
\[Alpha]::usage= "Standard Schwinger parameter."
MyPropagators::usage= "List of propagators choosen by SOFIABaikov."
MySubstitutions::usage= "Denotes the list of substitutions generated by SOFIABaikov."
TrySolveStandardLandau::usage= "This functions will try to solve standard Landau equations. It is not optimized for complicated examples."
findUniqueSelection::usage ="..."
prepareLandauSystem::usage ="..."
(*-----PLD related-----*)
momentumPLD::usage= "This function wraps the solvers (numerical (num) or symbolic (sym)) behind PLD.jl."
EulerDiscriminant::usage= "This function wraps the EulerDiscriminant function in PLD.jl. It can be used to detect drop in Euler characteristic near given candidate singularities."
(*-----Effortless-----*)
r::usage= "Letter used by Effortless to denote a root."
w::usage= "Letter used by Effortless to denote a rational log entry."
RunEffortless::usage = "RunEffortless[SqrtList,EvenAlpha,SqrtRepl,vars] - constructs all possible odd letters for a given list of square roots SqrtList and a given list of even letters EvenAlpha. SqrtRepl contains replacement rules sending the abstract square roots in SqrtList to their expressions in terms of the variables in vars."
RunEffortlessIndependent::usage="RunEffortlessIndependent[SqrtList,EvenAlpha,SqrtRepl,vars] - constructs all possible independent odd letters for a given list of square roots SqrtList and a given list of even letters EvenAlpha. SqrtRepl contains replacement rules sending the abstract square roots in SqrtList to their expressions in terms of the variables in vars."
RunEffortlessIndependentFF::usage="RunEffortlessIndependentFF[SqrtList,EvenAlpha,SqrtRepl,vars] - uses FiniteFlow to construct all possible independent odd letters for a given list of square roots SqrtList and a given list of even letters EvenAlpha. SqrtRepl contains replacement rules sending the abstract square roots in SqrtList to their expressions in terms of the variables in vars."
FindOddLetters::usage = "FindOddLetters[CurrentSqrt,AllowedEvenAlpha,SqrtRepl,vars] - finds all odd letters constructed using the squareroot Sqrt which factorize in terms of the even alphabet EvenAlpha."
AllowedEvenLetters::usage = "AllowedEvenLetters[CurrentSqrt,EvenAlpha,SqrtRepl,vars] - finds all even letters in EvenAlpha which can possibly show up in a factorization of an odd letter involving Sqrt."
SortAlphabetSublist::usage = "SortAlphabetSublist[EvenAlpha,vars] - sorts the letters in EvenAlpha with respect to their polynomial order in the variables vars and returns the sorted alphabet split in sublists corresponding to the polynomial order."
AlphabetPolynomialOrderKey::usage = "AlphabetPolynomialOrderKey[EvenAlpha,vars] - creates a key assigning every alphabet letter to its polynomial order in the variables vars."
ConstructProducts::usage = "ConstructProducts[CurrentSqrt,AllowedEvenAlpha,SqrtRepl,vars] - constructs all possible products of the right polynomial order for the square root Sqrt from the even subalphabet AllowedEvenAlpha."
AllowedProductQ::usage = "AllowedProductQ[CurrentSqrt,Prod,EvenAlpha,SqrtRepl,vars] - checks whether adding the abstract letter product Prod turns CurrentSqrt into a perfect square once EvenAlpha has been substituted."
AllowedLetterQ::usage = "AllowedLetterQ[SqrtArgument,EvenLetter,vars] - checks whether the letter EvenLetter is a letter that can possibly show up in the factorization of an odd letter involving SqrtArgument."
FindAllZeroLocations::usage = "FindAllZeroLocations[EvenAlpha] - finds the zero locations of all letters in EvenAlpha. (Only for letters which are polynomials of degree less than 5.)"
FactorOdd::usage="FactorOdd[OddLetter, SqrtRepl] - factorizes the product of numerator and denominator of OddLetter. SqrtRepl contains replacement rules for the appearing square root."
TakeDerivativeOfLetter::usage="TakeDerivativeOfLetter[Letter,SqrtRepl,vars,var] - takes the derivative of the letter Letter with respect to var. SqrtRepl contains replacement rules for the appearing square roots and vars is the list of variables."
TakeDerivativeOfLetterModSqrt::usage="TakeDerivativeOfLetterModSqrt[Letter,SqrtRepl,vars,var] - takes the derivative of the letter Letter with respect to var. If Letter is an odd letter with sqrt Q, the derivative is multiplied by Q. SqrtRepl contains replacement rules for the appearing square roots and vars is the list of variables."
FindIndependentLetters::usage="FindIndependentLetters[NewLetters,SqrtRepl,vars] - constructs the list of independent letters among NewLetters. SqrtRepl contains replacement rules for the appearing square roots and vars is the list of variables."
FindIndependentLettersFF::usage="FindIndependentLettersFF[NewLetters,SqrtRepl,vars] - uses FiniteFlow to construct the list of independent letters among NewLetters. SqrtRepl contains replacement rules for the appearing square roots and vars is the list of variables."
DecomposeInAlphabet::usage="DecomposeInAlphabet[AlphabetRepl,LetterToDecompose,SqrtRepl,vars] - decomposes the letter LetterToDecompose in terms of the alphabet provided in AlphabetRepl. SqrtRepl contains replacement rules for the appearing square roots and vars is the list of variables."
DecomposeInAlphabetFF::usage="DecomposeInAlphabetFF[AlphabetRepl,LetterToDecompose,SqrtRepl,vars] - uses FiniteFlow to decompose the letter LetterToDecompose in terms of the alphabet provided in AlphabetRepl. SqrtRepl contains replacement rules for the appearing square roots and vars is the list of variables."
FactorOddInAlphabet::usage="FactorOddInAlphabet[AlphabetRepl,OddLetter,SqrtRepl,vars] - factorizes the product of denominator and numerator of an odd letter OddLetter in terms of the alphabet provided in AlphabetRepl. SqrtRepl contains replacement rules for the appearing square roots and vars is the list of variables."
FactorOddInAlphabetFF::usage="FactorOddInAlphabetFF[AlphabetRepl,OddLetter,SqrtRepl,vars] - uses FiniteFlow to factorize the product of denominator and numerator of an odd letter OddLetter in terms of the alphabet provided in AlphabetRepl. SqrtRepl contains replacement rules for the appearing square roots and vars is the list of variables."
TakeDerivativeOfOdd::usage="TakeDerivativeOfOdd[Letter,SqrtRepl,vars,x] - takes the derivative of an odd letter Letter with respect to variable x."
ELImpossible::usage="Error Message for impossible decompositions."
FindLetters::usage="SOFIA wrapper for Effortless."
outEF::usage = "Output of FindLetters."
SqrtRepl::usage = "List of chosen square root entries."
evenAlpha::usage = "List of chosen rational entries."


Print["Copyright \[Copyright] 2025 Miguel Correia, Mathieu Giroux, and Sebastian Mizera. All rights reserved."]


If[$Notebooks, 
  Print["Available documented functions:"];
  Print @ Column[
    {
    "Applyd",
    "BrownPanzer",
    "ContractionsNontrivial",
    "EulerDiscriminant",
    "FastFubini",
    "FeynmanDraw",
    "FeynmanPlot",
    "FixLoopEdges",
    "GenerateKinematics",
    "IdentifyTheLoops",
    "LocalityConditions",
    "momentumPLD",
    "NumberOfCriticalPoints",
    "RunEffortless",
    "RunEffortlessIndependent",
    "RunEffortlessIndependentFF",
    "SOFIA",
    "SOFIABaikov",
    "SOFIASingularities",
    "TakeMaxCut",
    "TrySolveStandardLandau"
}, 
    Spacings -> 0.5
  ];
];
