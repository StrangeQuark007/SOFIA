singularities = { m2, m2 - 1/9*s, m2 - 1/9*t, m2 - s, m2 - t, m2*s + m2*t - 1/9*s*t, m2*s + m2*t - s*t, s, s + t, t };
